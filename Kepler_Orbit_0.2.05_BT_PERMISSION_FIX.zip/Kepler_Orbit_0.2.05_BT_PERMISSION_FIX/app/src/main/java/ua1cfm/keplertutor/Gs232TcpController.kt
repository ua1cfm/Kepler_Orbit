package ua1cfm.keplertutor

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** GS-232B transport over a plain TCP socket (default port 4533). */
class Gs232TcpController(private val context: Context) {
    data class Angles(val azimuthDeg: Double, val elevationDeg: Double)

    private var socket: Socket? = null
    private var input: BufferedInputStream? = null
    private var output: BufferedOutputStream? = null

    val isConnected: Boolean
        get() = socket?.let { it.isConnected && !it.isClosed } == true

    suspend fun connect(host: String, port: Int, timeoutMs: Int = 2500): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            closeSocketOnly()
            val s = Socket()
            s.tcpNoDelay = true
            s.keepAlive = true
            s.soTimeout = 1500
            s.connect(InetSocketAddress(host.trim(), port.coerceIn(1, 65535)), timeoutMs)
            socket = s
            input = BufferedInputStream(s.getInputStream())
            output = BufferedOutputStream(s.getOutputStream())
            "${host.trim()}:${port.coerceIn(1, 65535)}"
        }
    }

    suspend fun send(command: String): Boolean = withContext(Dispatchers.IO) {
        val out = output ?: return@withContext false
        runCatching {
            out.write((command.trim() + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
            true
        }.getOrDefault(false)
    }

    suspend fun query(command: String, waitMs: Long = 80L): String = withContext(Dispatchers.IO) {
        if (!send(command)) return@withContext ""
        readLineBlocking(timeoutMs = 1500)
    }

    suspend fun queryAngles(): Pair<Angles?, String> {
        val raw = query("C2")
        return parseAngles(raw) to raw
    }

    suspend fun setTarget(azimuthDeg: Double, elevationDeg: Double): Boolean {
        val az = azimuthDeg.coerceIn(0.0, 450.0).toInt()
        val el = elevationDeg.coerceIn(0.0, 180.0).toInt()
        return send("W%03d %03d".format(az, el))
    }

    suspend fun stop(): Boolean = send("S")
    suspend fun set360Mode(): Boolean = send("P36")
    suspend fun set450Mode(): Boolean = send("P45")

    private fun closeSocketOnly() {
        runCatching { input?.close() }
        runCatching { output?.close() }
        runCatching { socket?.close() }
        input = null
        output = null
        socket = null
    }

    fun close() {
        closeSocketOnly()
    }

    private fun readLineBlocking(timeoutMs: Int): String {
        val inp = input ?: return ""
        val sock = socket ?: return ""

        val oldTimeout = runCatching { sock.soTimeout }.getOrDefault(0)
        runCatching { sock.soTimeout = timeoutMs.coerceAtLeast(250) }

        val bytes = ArrayList<Byte>(64)
        try {
            while (bytes.size < 256) {
                val value = inp.read()
                if (value < 0) break

                val b = value.toByte()
                bytes.add(b)

                if (b == '\n'.code.toByte()) break
            }
        } catch (_: SocketTimeoutException) {
            // Return what has already arrived. Empty means a real missed reply.
        } finally {
            runCatching { sock.soTimeout = oldTimeout }
        }

        return bytes.toByteArray().toString(Charsets.US_ASCII).trim()
    }

    private fun parseAngles(text: String): Angles? {
        val normalized = text.replace("\r", " ").replace("\n", " ")
        val named = Regex("AZ\\s*=\\s*([+-]?\\d{1,4}).*?EL\\s*=\\s*([+-]?\\d{1,4})", RegexOption.IGNORE_CASE)
            .find(normalized)
        if (named != null) {
            val az = named.groupValues[1].toDoubleOrNull()
            val el = named.groupValues[2].toDoubleOrNull()
            if (az != null && el != null) return Angles(az, el)
        }
        val compact = Regex("([+-]\\d{4})\\s*([+-]\\d{4})").find(normalized.replace(" ", ""))
        if (compact != null) {
            val az = compact.groupValues[1].toDoubleOrNull()
            val el = compact.groupValues[2].toDoubleOrNull()
            if (az != null && el != null) return Angles(az, el)
        }
        return null
    }
}
