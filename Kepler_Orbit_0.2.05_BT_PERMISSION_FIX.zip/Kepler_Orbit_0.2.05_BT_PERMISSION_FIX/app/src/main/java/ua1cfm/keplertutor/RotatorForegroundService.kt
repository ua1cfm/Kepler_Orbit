package ua1cfm.keplertutor

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.net.wifi.WifiManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Date
import kotlin.math.abs
import kotlin.math.roundToInt

class RotatorForegroundService : Service() {

    data class UiState(
        val connected: Boolean = false,
        val tracking: Boolean = false,
        val transport: String = "USB",
        val status: String = "ROTATOR: отключено",
        val feedback: String = "AZ ---°  EL ---°",
        val actualAz: Double? = null,
        val actualEl: Double? = null,
        val targetMode: String = "SATELLITE"
    )

    companion object {
        private const val CHANNEL_ID = "rotator_control"
        private const val NOTIFICATION_ID = 232
        private const val ACTION_START = "ua1cfm.keplertutor.ROTATOR_SERVICE_START"

        @Volatile
        var instance: RotatorForegroundService? = null
            private set

        private val _state = MutableStateFlow(UiState())
        val state: StateFlow<UiState> = _state

        fun start(context: Context) {
            val intent = Intent(context, RotatorForegroundService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, intent)
        }

        suspend fun awaitInstance(timeoutMs: Long = 2500L): RotatorForegroundService? {
            val started = System.currentTimeMillis()
            while (instance == null && System.currentTimeMillis() - started < timeoutMs) {
                delay(25L)
            }
            return instance
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private lateinit var usb: Gs232UsbController
    private lateinit var tcp: Gs232TcpController
    private lateinit var bt: Gs232BluetoothController

    private var feedbackJob: Job? = null
    private var trackingJob: Job? = null
    private var reconnectJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val transportMutex = Mutex()

    private var lastNotificationKey: String? = null

    private val prefs by lazy { getSharedPreferences("rotator_foreground_service", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        usb = Gs232UsbController(applicationContext)
        tcp = Gs232TcpController(applicationContext)
        bt = Gs232BluetoothController(applicationContext)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("ROTATOR service ready"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        updateNotification(_state.value.status)
        if (prefs.getBoolean("desired_connected", false) && !_state.value.connected) {
            reconnectJob?.cancel()
            reconnectJob = serviceScope.launch {
                delay(500L)
                reconnectSavedConnection()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Kepler Orbit rotator",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Background GS-232 rotator control"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun buildNotification(text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Kepler Orbit • ROTATOR")
            .setContentText(text.take(90))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,
                    232,
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun publish(
        connected: Boolean = _state.value.connected,
        tracking: Boolean = _state.value.tracking,
        transport: String = _state.value.transport,
        status: String = _state.value.status,
        feedback: String = _state.value.feedback,
        actualAz: Double? = _state.value.actualAz,
        actualEl: Double? = _state.value.actualEl,
        targetMode: String = _state.value.targetMode
    ) {
        _state.value = UiState(
            connected = connected,
            tracking = tracking,
            transport = transport,
            status = status,
            feedback = feedback,
            actualAz = actualAz,
            actualEl = actualEl,
            targetMode = targetMode
        )

        // Keep the foreground notification stable.  C2 feedback changes every
        // 500 ms and must NOT re-post/re-sort the notification in the shade.
        val notificationKey = when {
            tracking -> "$transport|TRACK|$targetMode"
            connected -> "$transport|CONNECTED"
            else -> "$transport|DISCONNECTED"
        }

        if (notificationKey != lastNotificationKey) {
            lastNotificationKey = notificationKey
            updateNotification(
                when {
                    tracking -> "$transport • AUTO TRACK $targetMode"
                    connected -> "$transport • CONNECTED"
                    else -> "ROTATOR • DISCONNECTED"
                }
            )
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "KeplerOrbit:RotatorBackground"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wakeLock = null
    }

    @Suppress("DEPRECATION")
    private fun acquireWifiLockIfNeeded(transport: String) {
        if (transport != "TCP") { releaseWifiLock(); return }
        if (wifiLock?.isHeld == true) return
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "KeplerOrbit:RotatorTcp").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWifiLock() {
        runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
        wifiLock = null
    }

    private fun saveConnectionConfig(transport: String, tcpHost: String, tcpPort: Int, btAddress: String, mode: String, desired: Boolean) {
        prefs.edit()
            .putBoolean("desired_connected", desired)
            .putString("transport", transport)
            .putString("tcp_host", tcpHost)
            .putInt("tcp_port", tcpPort)
            .putString("bt_address", btAddress)
            .putString("mode", mode)
            .apply()
    }

    suspend fun connect(
        transport: String,
        tcpHost: String,
        tcpPort: Int,
        btAddress: String,
        mode: String
    ): Result<String> {
        saveConnectionConfig(transport, tcpHost, tcpPort, btAddress, mode, true)
        val result = connectInternal(transport, tcpHost, tcpPort, btAddress, mode, true)
        if (result.isSuccess) startFeedback()
        return result
    }

    private suspend fun connectInternal(
        transport: String, tcpHost: String, tcpPort: Int, btAddress: String, mode: String, showConnecting: Boolean
    ): Result<String> {
        disconnectTransportsOnly()
        if (showConnecting) publish(connected = false, tracking = _state.value.tracking, transport = transport, status = "Подключение $transport...")

        val result: Result<String> = when (transport) {
            "TCP" -> tcp.connect(tcpHost, tcpPort)
            "BT" -> bt.connect(btAddress)
            else -> withContext(Dispatchers.IO) {
                when (val r = usb.connectOrRequestPermission(9600)) {
                    is Gs232UsbController.ConnectResult.Connected -> Result.success(r.deviceName)
                    is Gs232UsbController.ConnectResult.PermissionRequested -> Result.failure(IllegalStateException("USB_PERMISSION:${r.deviceName}"))
                    is Gs232UsbController.ConnectResult.Error -> Result.failure(IllegalStateException(r.message))
                }
            }
        }

        if (result.isSuccess) {
            acquireWakeLock()
            acquireWifiLockIfNeeded(transport)
            publish(connected = true, transport = transport, status = "$transport GS-232 подключено: ${result.getOrNull()}")
            val modeOk = if (mode == "450") set450Mode() else set360Mode()
            if (!modeOk) publish(status = "$transport подключено, но не удалось установить P${if (mode == "450") "45" else "36"}")
            runCatching { queryAngles() }
        } else {
            val msg = result.exceptionOrNull()?.message.orEmpty()
            if (showConnecting) {
                if (msg.startsWith("USB_PERMISSION:")) publish(status = "Запрошено USB-разрешение для ${msg.removePrefix("USB_PERMISSION:")}. После ALLOW нажмите CONNECT ещё раз.")
                else publish(connected = false, transport = transport, status = "$transport GS-232 ошибка: ${msg.ifBlank { "connection failed" }}")
            }
        }
        return result
    }

    private suspend fun reconnectSavedConnection(): Boolean {
        if (!prefs.getBoolean("desired_connected", false)) return false
        val transport = prefs.getString("transport", "USB") ?: "USB"
        val host = prefs.getString("tcp_host", "192.168.4.1") ?: "192.168.4.1"
        val port = prefs.getInt("tcp_port", 4533)
        val btAddress = prefs.getString("bt_address", "") ?: ""
        val mode = prefs.getString("mode", "360") ?: "360"

        var delayMs = 1000L
        repeat(8) { attempt ->
            if (!prefs.getBoolean("desired_connected", false)) return false
            publish(status = "$transport • background reconnect ${attempt + 1}/8")
            val r = connectInternal(transport, host, port, btAddress, mode, false)
            if (r.isSuccess) {
                publish(connected = true, status = "$transport • связь восстановлена автоматически")
                return true
            }
            delay(delayMs)
            delayMs = (delayMs * 2).coerceAtMost(10000L)
        }
        publish(connected = false, status = "$transport • связь потеряна • watchdog продолжает попытки")
        return false
    }

    suspend fun disconnectAndStop() {
        prefs.edit().putBoolean("desired_connected", false).apply()
        trackingJob?.cancelAndJoin()
        trackingJob = null
        feedbackJob?.cancelAndJoin()
        feedbackJob = null
        disconnectTransportsOnly()
        releaseWifiLock()
        releaseWakeLock()
        publish(
            connected = false,
            tracking = false,
            status = "ROTATOR: отключено",
            feedback = "AZ ---°  EL ---°",
            actualAz = null,
            actualEl = null
        )
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun disconnectTransportsOnly() {
        usb.close()
        tcp.close()
        bt.close()
    }

    private fun isTransportConnected(): Boolean = when (_state.value.transport) {
        "TCP" -> tcp.isConnected
        "BT" -> bt.isConnected
        else -> usb.isConnected
    }

    private fun startFeedback() {
        feedbackJob?.cancel()
        feedbackJob = serviceScope.launch {
            var failures = 0
            while (isActive && prefs.getBoolean("desired_connected", false)) {
                val qr = runCatching { queryAngles() }.getOrNull()
                if (qr?.first != null) {
                    failures = 0
                    if (!_state.value.connected) publish(connected = true, status = "${_state.value.transport} • связь восстановлена")
                } else {
                    failures++
                }

                if (failures >= 8) {
                    val transport = prefs.getString("transport", _state.value.transport) ?: _state.value.transport
                    publish(status = "$transport • нет ответа C2 • переподключение...")
                    val restored = reconnectSavedConnection()
                    if (!restored) {
                        delay(10000L)
                    }
                    failures = 0
                }
                delay(500L)
            }
        }
    }

    suspend fun queryAngles(): Pair<Gs232UsbController.Angles?, String> =
        transportMutex.withLock {
            val result = when (_state.value.transport) {
                "TCP" -> {
                    val r = tcp.queryAngles()
                    r.first?.let { Gs232UsbController.Angles(it.azimuthDeg, it.elevationDeg) } to r.second
                }
                "BT" -> {
                    val r = bt.queryAngles()
                    r.first?.let { Gs232UsbController.Angles(it.azimuthDeg, it.elevationDeg) } to r.second
                }
                else -> usb.queryAngles()
            }

            result.first?.let { a ->
                publish(
                    feedback = "AZ ${"%.0f".format(a.azimuthDeg)}°  EL ${"%.0f".format(a.elevationDeg)}°",
                    actualAz = a.azimuthDeg,
                    actualEl = a.elevationDeg
                )
            }
            result
        }

    suspend fun setTarget(az: Double, el: Double): Boolean =
        transportMutex.withLock {
            when (_state.value.transport) {
                "TCP" -> tcp.setTarget(az, el)
                "BT" -> bt.setTarget(az, el)
                else -> usb.setTarget(az, el)
            }
        }

    suspend fun stopRotator(): Boolean =
        transportMutex.withLock {
            when (_state.value.transport) {
                "TCP" -> tcp.stop()
                "BT" -> bt.stop()
                else -> usb.stop()
            }
        }

    suspend fun set360Mode(): Boolean =
        transportMutex.withLock {
            when (_state.value.transport) {
                "TCP" -> tcp.set360Mode()
                "BT" -> bt.set360Mode()
                else -> usb.set360Mode()
            }
        }

    suspend fun set450Mode(): Boolean =
        transportMutex.withLock {
            when (_state.value.transport) {
                "TCP" -> tcp.set450Mode()
                "BT" -> bt.set450Mode()
                else -> usb.set450Mode()
            }
        }

    fun stopTracking() {
        trackingJob?.cancel()
        trackingJob = null
        publish(tracking = false, status = "AUTO TRACK остановлен")
    }

    fun startTracking(
        targetMode: String,
        tleName: String?,
        tleLine1: String?,
        tleLine2: String?,
        observerLat: Double,
        observerLon: Double,
        observerAltM: Double,
        periodMs: Long,
        minElevationDeg: Double,
        stepDeg: Double,
        rotatorMode: String,
        parkAfterLos: Boolean,
        parkAz: Double?,
        parkEl: Double?
    ): Boolean {
        if (!_state.value.connected) {
            publish(status = "Сначала подключите GS-232 контроллер")
            return false
        }

        val rec = if (targetMode == "SATELLITE") {
            if (tleLine1.isNullOrBlank() || tleLine2.isNullOrBlank()) {
                publish(status = "Не выбран спутник для AUTO TRACK")
                return false
            }
            TleParser.parse("${tleName ?: "SATELLITE"}\n$tleLine1\n$tleLine2").firstOrNull()
                ?: run {
                    publish(status = "Ошибка TLE для AUTO TRACK")
                    return false
                }
        } else null

        trackingJob?.cancel()
        publish(tracking = true, targetMode = targetMode, status = "AUTO TRACK $targetMode запущен")

        trackingJob = serviceScope.launch {
            var heldTargetAz: Double? = null
            var heldTargetEl: Double? = null
            var belowLimit = false
            var wasAboveHorizon = false

            fun normalizedAzimuth(az: Double): Double {
                var a = az % 360.0
                if (a < 0.0) a += 360.0
                return a
            }

            fun mapAzimuthForRotator(skyAz: Double, referenceAz: Double?): Double {
                val base = normalizedAzimuth(skyAz)
                if (rotatorMode != "450") return base
                val candidates = buildList {
                    add(base)
                    val extended = base + 360.0
                    if (extended <= 450.0) add(extended)
                }
                val ref = referenceAz ?: return candidates.first()
                return candidates.minByOrNull { abs(it - ref) } ?: base
            }

            fun azDifference(a: Double, b: Double): Double {
                return if (rotatorMode == "450") abs(a - b) else {
                    val d = abs(a - b) % 360.0
                    minOf(d, 360.0 - d)
                }
            }

            val allowedSteps = listOf(1.0, 3.0, 5.0, 7.0, 10.0)
            val step = allowedSteps.minByOrNull { abs(it - stepDeg) } ?: 3.0
            val minEl = minElevationDeg.coerceIn(0.0, 89.0)

            while (isActive && _state.value.connected) {
                val targetName = when (targetMode) {
                    "SUN" -> "SUN"
                    "MOON" -> "MOON"
                    else -> rec?.name ?: "SATELLITE"
                }

                val p = runCatching {
                    withContext(Dispatchers.Default) {
                        when (targetMode) {
                            "SUN" -> celestialLivePosition("SUN", System.currentTimeMillis(), observerLat, observerLon, observerAltM)
                            "MOON" -> celestialLivePosition("MOON", System.currentTimeMillis(), observerLat, observerLon, observerAltM)
                            else -> Sgp4Engine.position(rec!!, Date(), observerLat, observerLon, observerAltM)
                        }
                    }
                }.getOrNull()

                if (p == null) {
                    publish(status = "Ошибка расчёта цели $targetName")
                    delay(periodMs.coerceIn(500L, 10000L))
                    continue
                }

                if (p.elevationDeg >= 0.0) {
                    wasAboveHorizon = true
                } else if (parkAfterLos && wasAboveHorizon) {
                    val maxAz = if (rotatorMode == "450") 450.0 else 360.0
                    if (parkAz != null && parkEl != null &&
                        parkAz in 0.0..maxAz && parkEl in 0.0..180.0
                    ) {
                        val ok = runCatching { setTarget(parkAz, parkEl) }.getOrDefault(false)
                        publish(
                            tracking = false,
                            status = if (ok) {
                                "LOS • PARK → W%03d %03d".format(parkAz.roundToInt(), parkEl.roundToInt())
                            } else "LOS • ошибка PARK"
                        )
                    } else {
                        publish(tracking = false, status = "LOS • неверная PARK позиция")
                    }
                    break
                }

                val skyAz = normalizedAzimuth(p.azimuthDeg)
                val referenceAz = heldTargetAz ?: _state.value.actualAz
                val az = mapAzimuthForRotator(skyAz, referenceAz)
                val el = p.elevationDeg.coerceIn(-90.0, 180.0)

                if (p.elevationDeg >= minEl) {
                    if (belowLimit) {
                        heldTargetAz = null
                        heldTargetEl = null
                        belowLimit = false
                    }

                    if (heldTargetAz == null || heldTargetEl == null) {
                        val cmdAz = az.roundToInt().toDouble()
                        val cmdEl = el.coerceAtLeast(0.0).roundToInt().toDouble()
                        val ok = runCatching { setTarget(cmdAz, cmdEl) }.getOrDefault(false)
                        if (ok) {
                            heldTargetAz = az
                            heldTargetEl = el
                            publish(
                                status = "TRACK $targetName: INIT W%03d %03d • step %.0f°"
                                    .format(cmdAz.roundToInt(), cmdEl.roundToInt(), step)
                            )
                        } else publish(status = "Ошибка передачи команды W")
                    } else {
                        val daz = azDifference(az, heldTargetAz!!)
                        val del = abs(el - heldTargetEl!!)
                        val updateAz = daz >= step
                        val updateEl = del >= step

                        if (updateAz || updateEl) {
                            val nextAz = if (updateAz) az else heldTargetAz!!
                            val nextEl = if (updateEl) el.coerceAtLeast(0.0) else heldTargetEl!!.coerceAtLeast(0.0)
                            val cmdAz = nextAz.roundToInt()
                            val cmdEl = nextEl.roundToInt()
                            val ok = runCatching {
                                setTarget(cmdAz.toDouble(), cmdEl.toDouble())
                            }.getOrDefault(false)

                            if (ok) {
                                if (updateAz) heldTargetAz = az
                                if (updateEl) heldTargetEl = el
                                val changed = buildList {
                                    if (updateAz) add("AZ")
                                    if (updateEl) add("EL")
                                }.joinToString("+")
                                publish(
                                    status = "TRACK $targetName: $changed → W%03d %03d • ΔAZ %.1f° ΔEL %.1f° • step %.0f°"
                                        .format(cmdAz, cmdEl, daz, del, step)
                                )
                            } else publish(status = "Ошибка передачи команды W")
                        } else {
                            publish(
                                status = "TRACK $targetName: HOLD AZ %.0f° EL %.0f° • ΔAZ %.1f° ΔEL %.1f° • step %.0f°"
                                    .format(heldTargetAz, heldTargetEl, daz, del, step)
                            )
                        }
                    }
                } else {
                    if (!belowLimit) {
                        runCatching { stopRotator() }
                        belowLimit = true
                    }
                    publish(
                        status = "$targetName ниже ${"%.1f".format(minEl)}°: STOP • EL=${"%.1f".format(p.elevationDeg)}°"
                    )
                }

                delay(periodMs.coerceIn(500L, 10000L))
            }

            if (_state.value.tracking) {
                publish(tracking = false, status = "AUTO TRACK остановлен")
            }
        }
        return true
    }

    override fun onDestroy() {
        trackingJob?.cancel()
        feedbackJob?.cancel()
        disconnectTransportsOnly()
        releaseWifiLock()
        releaseWakeLock()
        instance = null
        _state.value = UiState()
        serviceScope.cancel()
        super.onDestroy()
    }
}
