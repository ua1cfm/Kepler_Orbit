plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ua1cfm.keplertutor"
    compileSdk = 35

    defaultConfig {
        applicationId = "ua1cfm.keplertutor"
        minSdk = 26
        targetSdk = 35
        versionCode = 56
        versionName = "0.1.56"
    }

    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.02.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")
    implementation("uk.me.g4dpz:predict4java:1.2.2")
    implementation("com.github.mik3y:usb-serial-for-android:3.9.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
