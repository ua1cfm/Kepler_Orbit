package ua1cfm.keplertutor

object TleParser {
    fun parse(text: String): List<TleRecord> {
        val lines = text.lineSequence().map { it.trimEnd() }.filter { it.isNotBlank() }.toList()
        val out = mutableListOf<TleRecord>()
        var i = 0
        while (i < lines.size) {
            val a = lines[i]
            val name: String
            val l1: String
            val l2: String
            if (a.startsWith("1 ") && i + 1 < lines.size && lines[i + 1].startsWith("2 ")) {
                name = "NORAD ${safeSlice(a, 2, 7).trim()}"
                l1 = a; l2 = lines[i + 1]; i += 2
            } else if (i + 2 < lines.size && lines[i + 1].startsWith("1 ") && lines[i + 2].startsWith("2 ")) {
                name = a.removePrefix("0 ").trim().ifBlank { "Unnamed satellite" }
                l1 = lines[i + 1]; l2 = lines[i + 2]; i += 3
            } else {
                i++; continue
            }
            runCatching { parseOne(name, l1, l2) }.getOrNull()?.let(out::add)
        }
        return out
    }

    private fun parseOne(name: String, l1: String, l2: String): TleRecord {
        fun s(x: String, a: Int, b: Int) = safeSlice(x, a, b).trim()
        val yy = s(l1, 18, 20).toInt()
        val year = if (yy >= 57) 1900 + yy else 2000 + yy
        return TleRecord(
            name = name,
            line1 = l1,
            line2 = l2,
            norad = s(l1, 2, 7).toInt(),
            classification = l1.getOrNull(7) ?: 'U',
            intlDesignator = s(l1, 9, 17),
            epochYear = year,
            epochDay = s(l1, 20, 32).toDouble(),
            meanMotionDot = s(l1, 33, 43).toDoubleOrNull() ?: 0.0,
            meanMotionDdot = parseCompactExponent(s(l1, 44, 52)),
            bstar = parseCompactExponent(s(l1, 53, 61)),
            ephemerisType = s(l1, 62, 63).toIntOrNull() ?: 0,
            elementSet = s(l1, 64, 68).toIntOrNull() ?: 0,
            inclinationDeg = s(l2, 8, 16).toDouble(),
            raanDeg = s(l2, 17, 25).toDouble(),
            eccentricity = ("0." + s(l2, 26, 33)).toDouble(),
            argPerigeeDeg = s(l2, 34, 42).toDouble(),
            meanAnomalyDeg = s(l2, 43, 51).toDouble(),
            meanMotionRevDay = s(l2, 52, 63).toDouble(),
            revolutionNumber = s(l2, 63, 68).toIntOrNull() ?: 0,
        )
    }

    private fun parseCompactExponent(raw: String): Double {
        val t = raw.replace(" ", "")
        if (t.isBlank()) return 0.0
        val m = Regex("([+-]?)(\\d{5})([+-]\\d)").matchEntire(t) ?: return t.toDoubleOrNull() ?: 0.0
        val sign = if (m.groupValues[1] == "-") -1 else 1
        val mant = m.groupValues[2].toDouble() / 1e5
        val exp = m.groupValues[3].toInt()
        return sign * mant * Math.pow(10.0, exp.toDouble())
    }

    private fun safeSlice(s: String, a: Int, b: Int): String {
        if (a >= s.length) return ""
        return s.substring(a, b.coerceAtMost(s.length))
    }
}
