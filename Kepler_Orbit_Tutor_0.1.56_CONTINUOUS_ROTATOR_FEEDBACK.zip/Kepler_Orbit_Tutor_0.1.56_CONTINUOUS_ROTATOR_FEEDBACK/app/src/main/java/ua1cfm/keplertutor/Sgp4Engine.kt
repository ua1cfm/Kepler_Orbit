package ua1cfm.keplertutor

import uk.me.g4dpz.satellite.GroundStationPosition
import uk.me.g4dpz.satellite.SatPos
import uk.me.g4dpz.satellite.SatelliteFactory
import uk.me.g4dpz.satellite.TLE
import java.util.Date
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

data class LivePosition(
    val latitudeDeg: Double,
    val longitudeDeg: Double,
    val altitudeKm: Double,
    val azimuthDeg: Double,
    val elevationDeg: Double,
    val rangeKm: Double,
    val rangeRateKmS: Double,
)

data class GroundPoint(val latDeg: Double, val lonDeg: Double, val altitudeKm: Double = 0.0)

object Sgp4Engine {

    private const val EARTH_RADIUS_KM = 6378.137

    fun horizonCentralAngleRad(altitudeKm: Double): Double {
        val h = altitudeKm.coerceAtLeast(0.0)
        return acos((EARTH_RADIUS_KM / (EARTH_RADIUS_KM + h)).coerceIn(-1.0, 1.0))
    }

    fun horizonSurfaceRadiusKm(altitudeKm: Double): Double = EARTH_RADIUS_KM * horizonCentralAngleRad(altitudeKm)

    fun visibilityFootprint(latitudeDeg: Double, longitudeDeg: Double, altitudeKm: Double, points: Int = 181): List<GroundPoint> {
        val lat1 = Math.toRadians(latitudeDeg)
        val lon1 = Math.toRadians(longitudeDeg)
        val d = horizonCentralAngleRad(altitudeKm)
        return (0 until points).map { i ->
            val brg = 2.0 * PI * i / (points - 1.0)
            val lat2 = asin(sin(lat1) * cos(d) + cos(lat1) * sin(d) * cos(brg))
            val lon2 = lon1 + atan2(
                sin(brg) * sin(d) * cos(lat1),
                cos(d) - sin(lat1) * sin(lat2)
            )
            var lonDeg = Math.toDegrees(lon2)
            while (lonDeg > 180.0) lonDeg -= 360.0
            while (lonDeg < -180.0) lonDeg += 360.0
            GroundPoint(Math.toDegrees(lat2), lonDeg)
        }
    }

    fun observerInsideFootprint(satLatDeg: Double, satLonDeg: Double, altitudeKm: Double, observerLatDeg: Double, observerLonDeg: Double): Boolean {
        val lat1 = Math.toRadians(satLatDeg)
        val lat2 = Math.toRadians(observerLatDeg)
        val dLon = Math.toRadians(observerLonDeg - satLonDeg)
        val cosAngle = (sin(lat1) * sin(lat2) + cos(lat1) * cos(lat2) * cos(dLon)).coerceIn(-1.0, 1.0)
        return acos(cosAngle) <= horizonCentralAngleRad(altitudeKm)
    }
    private fun tle(rec: TleRecord) = TLE(arrayOf(rec.name, rec.line1, rec.line2))

    fun position(rec: TleRecord, at: Date, observerLat: Double, observerLon: Double, observerAltM: Double): LivePosition {
        val sat = SatelliteFactory.createSatellite(tle(rec))
        val gs = GroundStationPosition(observerLat, observerLon, observerAltM)
        val p: SatPos = sat.getPosition(gs, at)
        return LivePosition(
            latitudeDeg = Math.toDegrees(p.latitude),
            longitudeDeg = Math.toDegrees(p.longitude),
            altitudeKm = p.altitude,
            azimuthDeg = Math.toDegrees(p.azimuth),
            elevationDeg = Math.toDegrees(p.elevation),
            rangeKm = p.range,
            rangeRateKmS = p.rangeRate,
        )
    }

    fun track(rec: TleRecord, center: Date = Date(), points: Int = 180): List<GroundPoint> {
        val sat = SatelliteFactory.createSatellite(tle(rec))
        val spanSec = (rec.periodMinutes * 60.0).coerceAtLeast(60.0)
        return (0 until points).map { idx ->
            val dt = -spanSec / 2.0 + spanSec * idx / (points - 1.0)
            sat.calculateSatelliteVectors(Date(center.time + (dt * 1000).toLong()))
            val p = sat.calculateSatelliteGroundTrack()
            var lonDeg = Math.toDegrees(p.longitude)
            while (lonDeg > 180.0) lonDeg -= 360.0
            while (lonDeg < -180.0) lonDeg += 360.0
            GroundPoint(Math.toDegrees(p.latitude), lonDeg, p.altitude)
        }
    }

    fun dopplerHz(rangeRateKmS: Double, frequencyHz: Double): Double {
        val cKmS = 299792.458
        return -frequencyHz * rangeRateKmS / cKmS
    }
}
