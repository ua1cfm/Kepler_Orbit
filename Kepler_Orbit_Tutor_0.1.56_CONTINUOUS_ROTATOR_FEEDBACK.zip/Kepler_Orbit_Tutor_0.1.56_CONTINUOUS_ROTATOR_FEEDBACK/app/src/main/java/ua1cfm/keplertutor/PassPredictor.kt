package ua1cfm.keplertutor

import java.util.Date
import kotlin.math.max

/** One visible/usable pass for the current observer. AOS/LOS are defined by the selected elevation threshold. */
data class SatellitePass(
    val aos: Date,
    val maxTime: Date,
    val los: Date,
    val aosAzDeg: Double,
    val maxAzDeg: Double,
    val losAzDeg: Double,
    val maxElevationDeg: Double,
    val maxRangeKm: Double,
) {
    val durationSeconds: Long get() = ((los.time - aos.time) / 1000L).coerceAtLeast(0L)
}

object PassPredictor {
    /**
     * Finds passes by sampling SGP4 elevation and refining crossings of minElevationDeg.
     *
     * Important behavior:
     * - minElevationDeg is the actual AOS/LOS boundary, not only a post-filter.
     * - if calculation starts while the satellite is already above that boundary,
     *   the real AOS is searched backwards instead of using "now" as AOS.
     */
    fun nextPasses(
        rec: TleRecord,
        observerLat: Double,
        observerLon: Double,
        observerAltM: Double,
        start: Date = Date(),
        horizonHours: Int = 48,
        minElevationDeg: Double = 0.0,
        maxPasses: Int = 10,
    ): List<SatellitePass> {
        val out = mutableListOf<SatellitePass>()
        val threshold = minElevationDeg.coerceIn(0.0, 89.0)
        val stepMs = 30_000L
        val requestedStartMs = start.time
        val endMs = requestedStartMs + horizonHours.coerceAtLeast(1) * 3600_000L

        var t0 = requestedStartMs
        var p0 = Sgp4Engine.position(rec, Date(t0), observerLat, observerLon, observerAltM)
        var inPass = p0.elevationDeg >= threshold
        var aosTime: Long? = null
        var aosAz = 0.0
        var maxTime = t0
        var maxEl = -90.0

        if (inPass) {
            // We opened the schedule during an already active pass. Search backwards
            // far enough to find the real rising threshold crossing.
            val backLimitMs = requestedStartMs - max((rec.periodMinutes * 60_000.0).toLong(), 2L * 3600_000L)
            var highMs = requestedStartMs
            var highPos = p0
            var lowMs = highMs - stepMs
            var lowPos = Sgp4Engine.position(rec, Date(lowMs), observerLat, observerLon, observerAltM)

            while (lowMs > backLimitMs && lowPos.elevationDeg >= threshold) {
                highMs = lowMs
                highPos = lowPos
                lowMs -= stepMs
                lowPos = Sgp4Engine.position(rec, Date(lowMs), observerLat, observerLon, observerAltM)
            }

            val realAos = if (lowPos.elevationDeg < threshold && highPos.elevationDeg >= threshold) {
                refineCrossing(rec, observerLat, observerLon, observerAltM, lowMs, highMs, threshold, rising = true)
            } else {
                // Defensive fallback: should only happen for unusual pathological data.
                requestedStartMs
            }
            val ap = Sgp4Engine.position(rec, Date(realAos), observerLat, observerLon, observerAltM)
            aosTime = realAos
            aosAz = ap.azimuthDeg
            t0 = realAos
            p0 = ap
            maxTime = realAos
            maxEl = ap.elevationDeg
        }

        var t1 = t0 + stepMs
        while (t1 <= endMs && out.size < maxPasses) {
            val p1 = Sgp4Engine.position(rec, Date(t1), observerLat, observerLon, observerAltM)

            if (!inPass && p0.elevationDeg < threshold && p1.elevationDeg >= threshold) {
                val cross = refineCrossing(
                    rec, observerLat, observerLon, observerAltM,
                    t0, t1, threshold, rising = true
                )
                val cp = Sgp4Engine.position(rec, Date(cross), observerLat, observerLon, observerAltM)
                inPass = true
                aosTime = cross
                aosAz = cp.azimuthDeg
                maxTime = cross
                maxEl = cp.elevationDeg
            }

            if (inPass && p1.elevationDeg > maxEl) {
                maxEl = p1.elevationDeg
                maxTime = t1
            }

            if (inPass && p0.elevationDeg >= threshold && p1.elevationDeg < threshold) {
                val cross = refineCrossing(
                    rec, observerLat, observerLon, observerAltM,
                    t0, t1, threshold, rising = false
                )
                val lp = Sgp4Engine.position(rec, Date(cross), observerLat, observerLon, observerAltM)
                val startMs = aosTime ?: t0
                val refinedMax = refineMaximum(
                    rec, observerLat, observerLon, observerAltM,
                    startMs, cross, maxTime
                )
                val mp = Sgp4Engine.position(rec, Date(refinedMax), observerLat, observerLon, observerAltM)

                out += SatellitePass(
                    aos = Date(startMs),
                    maxTime = Date(refinedMax),
                    los = Date(cross),
                    aosAzDeg = aosAz,
                    maxAzDeg = mp.azimuthDeg,
                    losAzDeg = lp.azimuthDeg,
                    maxElevationDeg = mp.elevationDeg,
                    maxRangeKm = mp.rangeKm,
                )

                inPass = false
                aosTime = null
                maxEl = -90.0
            }

            t0 = t1
            p0 = p1
            t1 += stepMs
        }
        return out
    }

    private fun refineCrossing(
        rec: TleRecord,
        lat: Double,
        lon: Double,
        alt: Double,
        a0: Long,
        b0: Long,
        thresholdDeg: Double,
        rising: Boolean,
    ): Long {
        var a = a0
        var b = b0
        repeat(20) {
            val m = (a + b) ushr 1
            val e = Sgp4Engine.position(rec, Date(m), lat, lon, alt).elevationDeg
            if (rising) {
                if (e >= thresholdDeg) b = m else a = m
            } else {
                if (e >= thresholdDeg) a = m else b = m
            }
        }
        return (a + b) / 2
    }

    private fun refineMaximum(
        rec: TleRecord,
        lat: Double,
        lon: Double,
        alt: Double,
        aosMs: Long,
        losMs: Long,
        seedMs: Long,
    ): Long {
        var center = seedMs.coerceIn(aosMs, losMs)
        var span = minOf(120_000L, ((losMs - aosMs) / 2L).coerceAtLeast(1_000L))
        repeat(8) {
            var bestT = center
            var bestE = -90.0
            for (k in -4..4) {
                val t = (center + k * span / 4L).coerceIn(aosMs, losMs)
                val e = Sgp4Engine.position(rec, Date(t), lat, lon, alt).elevationDeg
                if (e > bestE) {
                    bestE = e
                    bestT = t
                }
            }
            center = bestT
            span = (span / 3L).coerceAtLeast(125L)
        }
        return center
    }
}
