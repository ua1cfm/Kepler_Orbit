package ua1cfm.keplertutor

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sqrt

data class TleRecord(
    val name: String,
    val line1: String,
    val line2: String,
    val norad: Int,
    val classification: Char,
    val intlDesignator: String,
    val epochYear: Int,
    val epochDay: Double,
    val meanMotionDot: Double,
    val meanMotionDdot: Double,
    val bstar: Double,
    val ephemerisType: Int,
    val elementSet: Int,
    val inclinationDeg: Double,
    val raanDeg: Double,
    val eccentricity: Double,
    val argPerigeeDeg: Double,
    val meanAnomalyDeg: Double,
    val meanMotionRevDay: Double,
    val revolutionNumber: Int,
) {
    val epochInstant: Instant get() {
        val y = epochYear
        val dayInt = epochDay.toInt().coerceAtLeast(1)
        val fraction = epochDay - dayInt
        val base = LocalDate.ofYearDay(y, dayInt).atStartOfDay().toInstant(ZoneOffset.UTC)
        return base.plusMillis((fraction * 86400000.0).toLong())
    }

    val periodMinutes: Double get() = 1440.0 / meanMotionRevDay
    val semiMajorKm: Double get() {
        val mu = 398600.4418
        val n = meanMotionRevDay * 2.0 * PI / 86400.0
        return (mu / (n * n)).pow(1.0 / 3.0)
    }
    val perigeeAltKm: Double get() = semiMajorKm * (1.0 - eccentricity) - 6378.137
    val apogeeAltKm: Double get() = semiMajorKm * (1.0 + eccentricity) - 6378.137
    val perigeeRadiusKm: Double get() = semiMajorKm * (1.0 - eccentricity)
    val apogeeRadiusKm: Double get() = semiMajorKm * (1.0 + eccentricity)
    val perigeeSpeedKmS: Double get() = visViva(perigeeRadiusKm)
    val apogeeSpeedKmS: Double get() = visViva(apogeeRadiusKm)
    val orbitalClass: String get() = when {
        perigeeAltKm < 2000 && periodMinutes < 128 -> "LEO — низкая околоземная орбита"
        periodMinutes in 700.0..730.0 -> "MEO / около 12 ч"
        periodMinutes in 1420.0..1460.0 && eccentricity < 0.1 -> "GEO/GSO-like — геосинхронная"
        eccentricity > 0.25 -> "Высокоэллиптическая орбита"
        else -> "Средняя/высокая околоземная орбита"
    }
    val inclinationClass: String get() = when {
        inclinationDeg < 5 -> "экваториальная"
        inclinationDeg > 95 && inclinationDeg < 105 -> "почти полярная, ретроградная"
        inclinationDeg > 85 && inclinationDeg < 95 -> "почти полярная"
        inclinationDeg > 90 -> "ретроградная"
        else -> "наклонная проградная"
    }

    private fun visViva(rKm: Double): Double {
        val mu = 398600.4418
        return sqrt(mu * (2.0 / rKm - 1.0 / semiMajorKm))
    }
}
