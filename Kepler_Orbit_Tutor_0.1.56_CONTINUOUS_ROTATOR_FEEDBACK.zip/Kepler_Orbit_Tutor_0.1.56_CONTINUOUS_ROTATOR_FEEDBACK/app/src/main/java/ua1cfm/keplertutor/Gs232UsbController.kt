package ua1cfm.keplertutor

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.FtdiSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * GS-232B transport over Android USB host / OTG.
 *
 * Uses usb-serial-for-android so the phone can talk to the common USB UART
 * bridges that appear as COM ports on a PC: CDC-ACM, FTDI, CP210x,
 * Prolific PL2303 and CH340/CH341.
 *
 * IMPORTANT: a MAX232 on a DB9 board is only an RS-232 level shifter. Such a
 * board still needs a USB-to-RS232 adapter between the Android OTG port and DB9.
 */
class Gs232UsbController(private val context: Context) {
    companion object {
        private const val ACTION_USB_PERMISSION = "ua1cfm.keplertutor.USB_PERMISSION_GS232"
        private const val DEFAULT_BAUD = 9600
    }

    sealed class ConnectResult {
        data class Connected(val deviceName: String) : ConnectResult()
        data class PermissionRequested(val deviceName: String) : ConnectResult()
        data class Error(val message: String) : ConnectResult()
    }

    data class Angles(val azimuthDeg: Double, val elevationDeg: Double)

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var driver: UsbSerialDriver? = null
    private var port: UsbSerialPort? = null

    val isConnected: Boolean get() = port?.isOpen == true

    /**
     * Returns all serial drivers visible to Android.
     *
     * The normal usb-serial-for-android prober already supports FTDI, but some
     * FT232RL boards/clones expose a PID that is not present in the built-in
     * table.  For FTDI vendor 0x0403 we therefore add a direct FtdiSerialDriver
     * fallback.  Standard FT232RL is VID:PID 0403:6001.
     */
    fun candidateDrivers(): List<UsbSerialDriver> {
        val found = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).toMutableList()
        val known = found.map { it.device.deviceId }.toMutableSet()
        usbManager.deviceList.values.forEach { d ->
            val looksFtdi = d.vendorId == 0x0403 ||
                (d.manufacturerName?.contains("FTDI", ignoreCase = true) == true) ||
                (d.productName?.contains("FT232", ignoreCase = true) == true)
            if (looksFtdi && d.deviceId !in known) {
                found += FtdiSerialDriver(d)
                known += d.deviceId
            }
        }
        return found
    }

    fun candidateDevices(): List<UsbDevice> = candidateDrivers().map { it.device }

    fun rawUsbDevices(): List<UsbDevice> = usbManager.deviceList.values.toList()


    /**
     * Raw Android USB-host diagnostic. This intentionally bypasses
     * usb-serial-for-android and reports only what UsbManager itself enumerates.
     */
    fun rawUsbDiagnostics(): String {
        val devices = rawUsbDevices()
        if (devices.isEmpty()) {
            return "USB RAW TEST: 0 devices. Android UsbManager.deviceList is empty. FTDI driver is not involved yet."
        }
        return buildString {
            append("USB RAW TEST: ${devices.size} device(s)\n")
            devices.forEachIndexed { index, d ->
                val vid = "%04X".format(d.vendorId)
                val pid = "%04X".format(d.productId)
                val permission = usbManager.hasPermission(d)
                append("#${index + 1} id=${d.deviceId} VID:$vid PID:$pid permission=$permission")
                d.manufacturerName?.let { append("\n  manufacturer=$it") }
                d.productName?.let { append("\n  product=$it") }
                d.serialNumber?.let { append("\n  serial=$it") }
                append("\n  class=${d.deviceClass} subclass=${d.deviceSubclass} protocol=${d.deviceProtocol} interfaces=${d.interfaceCount}")
                for (i in 0 until d.interfaceCount) {
                    val intf = d.getInterface(i)
                    append("\n  IF$i class=${intf.interfaceClass} sub=${intf.interfaceSubclass} proto=${intf.interfaceProtocol} ep=${intf.endpointCount}")
                    for (e in 0 until intf.endpointCount) {
                        val ep = intf.getEndpoint(e)
                        append("\n    EP$e addr=0x${"%02X".format(ep.address)} dir=${ep.direction} type=${ep.type} maxPkt=${ep.maxPacketSize}")
                    }
                }
                if (index != devices.lastIndex) append("\n")
            }
        }
    }

    fun rawUsbSummary(): String {
        val devices = rawUsbDevices()
        if (devices.isEmpty()) return "Android USB host sees no USB devices"
        return devices.joinToString(" | ") { d ->
            val vid = "%04X".format(d.vendorId)
            val pid = "%04X".format(d.productId)
            val name = d.productName ?: d.manufacturerName ?: "USB device"
            "$name VID:$vid PID:$pid"
        }
    }

    fun connectOrRequestPermission(baud: Int = DEFAULT_BAUD): ConnectResult {
        close()
        val drivers = candidateDrivers()
        val drv = drivers.firstOrNull()
            ?: return ConnectResult.Error(
                "USB serial driver not found. ${rawUsbSummary()}. " +
                    "FT232RL expected VID:PID 0403:6001. Check OTG host mode, cable and power."
            )
        val d = drv.device
        val label = usbLabel(d, drv)
        if (!usbManager.hasPermission(d)) {
            val pi = PendingIntent.getBroadcast(
                context,
                232,
                Intent(ACTION_USB_PERMISSION).setPackage(context.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            usbManager.requestPermission(d, pi)
            return ConnectResult.PermissionRequested(label)
        }
        return openDriver(drv, baud)
    }

    private fun openDriver(drv: UsbSerialDriver, baud: Int): ConnectResult {
        val d = drv.device
        val conn = usbManager.openDevice(d) ?: return ConnectResult.Error("Cannot open USB serial device.")
        val p = drv.ports.firstOrNull() ?: run {
            conn.close()
            return ConnectResult.Error("USB serial device has no serial port.")
        }
        return try {
            p.open(conn)
            p.setParameters(
                baud.coerceIn(1200, 115200),
                8,
                UsbSerialPort.STOPBITS_1,
                UsbSerialPort.PARITY_NONE
            )
            runCatching { p.dtr = true }
            runCatching { p.rts = true }
            driver = drv
            port = p
            ConnectResult.Connected(usbLabel(d, drv) + " • ${baud} 8N1")
        } catch (t: Throwable) {
            runCatching { p.close() }
            conn.close()
            ConnectResult.Error("USB serial open error: ${t.message}")
        }
    }

    private fun usbLabel(d: UsbDevice, drv: UsbSerialDriver): String {
        val vid = "%04X".format(d.vendorId)
        val pid = "%04X".format(d.productId)
        val chip = drv.javaClass.simpleName.removeSuffix("SerialDriver")
        val name = d.productName ?: d.manufacturerName ?: "USB serial"
        return "$name • $chip • VID:$vid PID:$pid"
    }

    suspend fun send(command: String): Boolean = withContext(Dispatchers.IO) {
        val p = port ?: return@withContext false
        val bytes = (command.trim() + "\r").toByteArray(Charsets.US_ASCII)
        runCatching { p.write(bytes, 1200); true }.getOrDefault(false)
    }

    suspend fun query(command: String, waitMs: Long = 100L): String = withContext(Dispatchers.IO) {
        if (!send(command)) return@withContext ""
        delay(waitMs)
        readAvailable()
    }

    private fun readAvailable(): String {
        val p = port ?: return ""
        val all = ArrayList<Byte>(128)
        val buf = ByteArray(256)
        repeat(5) {
            val n = runCatching { p.read(buf, 140) }.getOrDefault(0)
            if (n > 0) for (i in 0 until n) all.add(buf[i])
        }
        return all.toByteArray().toString(Charsets.US_ASCII).trim()
    }

    suspend fun queryAngles(): Pair<Angles?, String> {
        val raw = query("C2")
        return parseAngles(raw) to raw
    }

    suspend fun setTarget(azimuthDeg: Double, elevationDeg: Double): Boolean {
        val az = azimuthDeg.coerceIn(0.0, 450.0).toInt()
        val el = elevationDeg.coerceIn(0.0, 180.0).toInt()
        return send("W%03d %03d".format(az, el))
    }

    suspend fun stop(): Boolean = send("S")
    suspend fun set360Mode(): Boolean = send("P36")
    suspend fun set450Mode(): Boolean = send("P45")

    fun close() {
        runCatching { port?.close() }
        port = null
        driver = null
    }

    private fun parseAngles(text: String): Angles? {
        val normalized = text.replace("\r", " ").replace("\n", " ")
        val named = Regex("AZ\\s*=\\s*([+-]?\\d{1,4}).*?EL\\s*=\\s*([+-]?\\d{1,4})", RegexOption.IGNORE_CASE)
            .find(normalized)
        if (named != null) {
            val az = named.groupValues[1].toDoubleOrNull()
            val el = named.groupValues[2].toDoubleOrNull()
            if (az != null && el != null) return Angles(az, el)
        }
        val compact = Regex("([+-]\\d{4})\\s*([+-]\\d{4})").find(normalized.replace(" ", ""))
        if (compact != null) {
            val az = compact.groupValues[1].toDoubleOrNull()
            val el = compact.groupValues[2].toDoubleOrNull()
            if (az != null && el != null) return Angles(az, el)
        }
        return null
    }
}
