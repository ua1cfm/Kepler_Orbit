package ua1cfm.keplertutor

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.util.UUID

/**
 * GS-232B transport over Bluetooth Classic (BR/EDR) SPP / RFCOMM.
 *
 * Intended for modules such as HC-05 / HC-06 connected to an Arduino UART.
 * The Android device must be paired with the module in system Bluetooth settings
 * before it can be selected in Kepler Orbit.
 */
class Gs232BluetoothController(private val context: Context) {
    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    data class DeviceInfo(val name: String, val address: String) {
        val label: String get() = "$name • $address"
    }

    data class Angles(val azimuthDeg: Double, val elevationDeg: Double)

    private val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? get() = manager.adapter
    private var socket: BluetoothSocket? = null
    private var input: BufferedInputStream? = null
    private var output: BufferedOutputStream? = null

    val isConnected: Boolean get() = socket?.isConnected == true

    fun hasConnectPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun pairedDevices(): List<DeviceInfo> {
        if (!hasConnectPermission()) return emptyList()
        return adapter?.bondedDevices
            ?.map { DeviceInfo(it.name ?: "Bluetooth SPP", it.address) }
            ?.sortedBy { it.name.lowercase() }
            .orEmpty()
    }

    @SuppressLint("MissingPermission")
    suspend fun connect(address: String, timeoutMs: Int = 7000): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            close()
            if (!hasConnectPermission()) error("Bluetooth permission is not granted")
            val a = adapter ?: error("Bluetooth is not supported on this Android device")
            if (!a.isEnabled) error("Bluetooth is turned off")
            val mac = address.trim()
            if (!BluetoothAdapter.checkBluetoothAddress(mac)) error("Invalid Bluetooth MAC address")
            val device = a.getRemoteDevice(mac)
            a.cancelDiscovery()
            val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
            // RFCOMM connect() has no native timeout. The socket is closed if the coroutine fails/cancels.
            s.connect()
            socket = s
            input = BufferedInputStream(s.inputStream)
            output = BufferedOutputStream(s.outputStream)
            "${device.name ?: "Bluetooth SPP"} • ${device.address} • RFCOMM/SPP"
        }
    }

    suspend fun send(command: String): Boolean = withContext(Dispatchers.IO) {
        val out = output ?: return@withContext false
        runCatching {
            out.write((command.trim() + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
            true
        }.getOrDefault(false)
    }

    suspend fun query(command: String, waitMs: Long = 100L): String = withContext(Dispatchers.IO) {
        if (!send(command)) return@withContext ""
        delay(waitMs)
        readAvailable()
    }

    suspend fun queryAngles(): Pair<Angles?, String> {
        val raw = query("C2")
        return parseAngles(raw) to raw
    }

    suspend fun setTarget(azimuthDeg: Double, elevationDeg: Double): Boolean {
        val az = azimuthDeg.coerceIn(0.0, 450.0).toInt()
        val el = elevationDeg.coerceIn(0.0, 180.0).toInt()
        return send("W%03d %03d".format(az, el))
    }

    suspend fun stop(): Boolean = send("S")
    suspend fun set360Mode(): Boolean = send("P36")
    suspend fun set450Mode(): Boolean = send("P45")

    fun close() {
        runCatching { input?.close() }
        runCatching { output?.close() }
        runCatching { socket?.close() }
        input = null
        output = null
        socket = null
    }

    private fun readAvailable(): String {
        val inp = input ?: return ""
        val bytes = ArrayList<Byte>(128)
        val buf = ByteArray(256)
        repeat(5) {
            val available = runCatching { inp.available() }.getOrDefault(0)
            if (available <= 0) return@repeat
            val n = runCatching { inp.read(buf, 0, minOf(buf.size, available)) }.getOrDefault(-1)
            if (n > 0) for (i in 0 until n) bytes.add(buf[i])
        }
        return bytes.toByteArray().toString(Charsets.US_ASCII).trim()
    }

    private fun parseAngles(text: String): Angles? {
        val normalized = text.replace("\r", " ").replace("\n", " ")
        val named = Regex("AZ\\s*=\\s*([+-]?\\d{1,4}).*?EL\\s*=\\s*([+-]?\\d{1,4})", RegexOption.IGNORE_CASE)
            .find(normalized)
        if (named != null) {
            val az = named.groupValues[1].toDoubleOrNull()
            val el = named.groupValues[2].toDoubleOrNull()
            if (az != null && el != null) return Angles(az, el)
        }
        val compact = Regex("([+-]\\d{4})\\s*([+-]\\d{4})").find(normalized.replace(" ", ""))
        if (compact != null) {
            val az = compact.groupValues[1].toDoubleOrNull()
            val el = compact.groupValues[2].toDoubleOrNull()
            if (az != null && el != null) return Angles(az, el)
        }
        return null
    }
}
