package ua1cfm.keplertutor

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Looper
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.roundToInt

private val Bg = Color(0xFF07111F)
private val Card = Color(0xFF101F33)
private val Accent = Color(0xFF55B6FF)
private val Good = Color(0xFF78E08F)
private val Warn = Color(0xFFFFD166)

private fun formatTleFileDataAge(records: List<TleRecord>, nowMs: Long): String {
    if (records.isEmpty()) return ""
    val newestEpochMs = records.maxOfOrNull { it.epochInstant.toEpochMilli() } ?: return ""
    val deltaMs = nowMs - newestEpochMs

    if (deltaMs < 0L) {
        val futureMinutes = ((-deltaMs) / 60_000L).coerceAtLeast(1L)
        return if (futureMinutes < 60L) {
            "данные TLE впереди на ${futureMinutes} мин"
        } else {
            val h = futureMinutes / 60L
            val m = futureMinutes % 60L
            if (m == 0L) "данные TLE впереди на ${h} ч"
            else "данные TLE впереди на ${h} ч ${m} мин"
        }
    }

    val totalMinutes = deltaMs / 60_000L
    return when {
        totalMinutes < 1L -> "меньше 1 мин"
        totalMinutes < 60L -> "${totalMinutes} мин"
        totalMinutes < 1440L -> {
            val h = totalMinutes / 60L
            val m = totalMinutes % 60L
            if (m == 0L) "${h} ч" else "${h} ч ${m} мин"
        }
        else -> {
            val days = totalMinutes / 1440L
            val hours = (totalMinutes % 1440L) / 60L
            val mins = totalMinutes % 60L
            when {
                hours == 0L && mins == 0L -> "${days} д"
                mins == 0L -> "${days} д ${hours} ч"
                else -> "${days} д ${hours} ч ${mins} мин"
            }
        }
    }
}


private fun formatAosCountdown(targetMs: Long, nowMs: Long): String {
    val remainMs = (targetMs - nowMs).coerceAtLeast(0L)
    val totalSeconds = remainMs / 1000L
    val days = totalSeconds / 86_400L
    val hours = (totalSeconds % 86_400L) / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L

    return if (days > 0L) {
        "AOS через ${days} д %02d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "AOS через %02d:%02d:%02d".format(hours, minutes, seconds)
    }
}

@Composable
private fun ControlButtonText(
    text: String,
    fontSize: TextUnit = 12.sp,
    fontWeight: FontWeight? = null
) {
    Text(
        text = text,
        fontSize = fontSize,
        fontWeight = fontWeight,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val systemDensity = LocalDensity.current
            // UI scale normalization: keep Compose SP geometry stable across phones with different Android Font size settings.
            CompositionLocalProvider(
                LocalDensity provides Density(systemDensity.density, fontScale = 1f)
            ) {
                MaterialTheme(colorScheme = darkColorScheme()) { TutorApp(this) }
            }
        }
    }
}

private const val PREFS_NAME = "kepler_orbit_tutor_prefs"
private const val SAVED_TLE_FILE = "saved_kepler_tle.txt"

private data class SkyPoint(val azimuthDeg: Double, val elevationDeg: Double)
private data class RadarPreview(val points: List<SkyPoint>, val label: String, val activeNow: Boolean)
private data class ScheduledPass(val rec: TleRecord, val pass: SatellitePass)

private data class MapSatelliteOrbit(
    val rec: TleRecord,
    val track: List<GroundPoint>,
    val live: LivePosition?
)

private fun secondaryOrbitColor(index: Int): Color {
    val palette = listOf(
        Color(0xFFFFC857),
        Color(0xFF9BE564),
        Color(0xFFFF6B6B),
        Color(0xFFC792EA),
        Color(0xFF4DD0E1),
        Color(0xFFFF8A65),
        Color(0xFFAED581),
        Color(0xFFF48FB1)
    )
    return palette[index.mod(palette.size)]
}

private fun saveTleToInternal(context: Context, text: String) {
    context.openFileOutput(SAVED_TLE_FILE, Context.MODE_PRIVATE).bufferedWriter(Charsets.UTF_8).use { it.write(text) }
}

private fun loadSavedTle(context: Context): String? = runCatching {
    context.openFileInput(SAVED_TLE_FILE).bufferedReader(Charsets.UTF_8).use { it.readText() }
}.getOrNull()?.takeIf { it.isNotBlank() }

private fun deleteSavedTle(context: Context) {
    runCatching { context.deleteFile(SAVED_TLE_FILE) }
}


private fun buildPassChimePcm(isAos: Boolean, sampleRate: Int = 44_100): ShortArray {
    // Musical "satellite beacon":
    // AOS  C5 -> E5 -> G5 -> C6
    // LOS  C6 -> G5 -> E5 -> C5
    val frequencies = if (isAos) {
        doubleArrayOf(523.25, 659.25, 783.99, 1046.50)
    } else {
        doubleArrayOf(1046.50, 783.99, 659.25, 523.25)
    }
    val durationsMs = intArrayOf(180, 180, 230, 680)
    val gapsMs = intArrayOf(65, 65, 85, 0)

    val totalSamples = frequencies.indices.sumOf { i ->
        ((durationsMs[i] + gapsMs[i]) * sampleRate / 1000)
    }
    val pcm = ShortArray(totalSamples)
    var out = 0

    frequencies.indices.forEach { i ->
        val toneSamples = durationsMs[i] * sampleRate / 1000
        val gapSamples = gapsMs[i] * sampleRate / 1000
        val attackSamples = (sampleRate * 0.018).toInt().coerceAtLeast(1)
        val releaseSamples = (sampleRate * if (i == frequencies.lastIndex) 0.11 else 0.055).toInt().coerceAtLeast(1)
        val f = frequencies[i]

        for (n in 0 until toneSamples) {
            val attack = (n.toDouble() / attackSamples).coerceIn(0.0, 1.0)
            val release = ((toneSamples - 1 - n).toDouble() / releaseSamples).coerceIn(0.0, 1.0)
            val envelope = minOf(attack, release)

            val phase = 2.0 * PI * f * n / sampleRate
            // Fundamental plus gentle harmonics gives a softer "bell/beacon" sound
            // than the standard Android telephone beep.
            val sample =
                sin(phase) * 0.76 +
                sin(phase * 2.0) * 0.17 +
                sin(phase * 3.0) * 0.07

            pcm[out++] = (sample * envelope * 0.42 * Short.MAX_VALUE)
                .roundToInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()
        }

        repeat(gapSamples) {
            if (out < pcm.size) pcm[out++] = 0
        }
    }
    return pcm
}

private suspend fun playPassAudioSignal(isAos: Boolean) = withContext(Dispatchers.IO) {
    val sampleRate = 44_100
    val pcm = buildPassChimePcm(isAos, sampleRate)

    val minBuffer = AudioTrack.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_OUT_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    ).coerceAtLeast(4096)

    val audioTrack = AudioTrack.Builder()
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        .setAudioFormat(
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
        )
        .setBufferSizeInBytes(minBuffer)
        .setTransferMode(AudioTrack.MODE_STREAM)
        .build()

    try {
        if (audioTrack.state == AudioTrack.STATE_INITIALIZED) {
            audioTrack.setVolume(1.0f)
            audioTrack.play()

            var offset = 0
            while (offset < pcm.size) {
                val count = minOf(2048, pcm.size - offset)
                val written = audioTrack.write(
                    pcm,
                    offset,
                    count,
                    AudioTrack.WRITE_BLOCKING
                )
                if (written <= 0) break
                offset += written
            }

            // Allow the final buffered samples to reach the speaker before release.
            delay(180)
            audioTrack.stop()
        }
    } finally {
        runCatching { audioTrack.flush() }
        audioTrack.release()
    }
}


private val MAP_STYLES = listOf("STANDARD", "POLITICAL", "POLITICAL COLOR", "NASA", "CONTROL", "ORBITRON")

private fun mapTextureCacheFile(context: Context, style: String): java.io.File =
    java.io.File(context.cacheDir, "kepler_map_${style.lowercase()}.img")

private fun mapTextureUrl(style: String): String? = when (style) {
    "POLITICAL" ->
        "https://commons.wikimedia.org/wiki/Special:Redirect/file/NED_worldmap_110m.svg?width=1600"
    "NASA" ->
        "https://assets.science.nasa.gov/content/dam/science/esd/eo/images/bmng/bmng-base/january/world.200401.3x5400x2700.jpg"
    else -> null
}

private fun downloadBitmapBytes(url: String): ByteArray {
    val c = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15000
        readTimeout = 30000
        requestMethod = "GET"
        instanceFollowRedirects = true
        setRequestProperty("User-Agent", "Kepler-Orbit/0.1.74 (Android; UA1CFM)")
        setRequestProperty("Accept", "image/png,image/jpeg,image/*,*/*;q=0.8")
        useCaches = true
    }
    try {
        val code = c.responseCode
        if (code !in 200..299) error("HTTP $code")
        return c.inputStream.use { it.readBytes() }
    } finally {
        c.disconnect()
    }
}

private fun loadMapTexture(context: Context, style: String): Bitmap {
    if (style == "STANDARD") {
        return BitmapFactory.decodeResource(context.resources, R.drawable.world_map)
            ?: error("Не удалось загрузить стандартную карту")
    }
    if (style == "CONTROL") {
        return BitmapFactory.decodeResource(context.resources, R.drawable.world_map_control)
            ?: error("Не удалось загрузить карту CONTROL")
    }
    if (style == "POLITICAL COLOR") {
        return BitmapFactory.decodeResource(context.resources, R.drawable.world_map_political_color)
            ?: error("Не удалось загрузить карту POLITICAL COLOR")
    }
    if (style == "ORBITRON") {
        return BitmapFactory.decodeResource(context.resources, R.drawable.world_map_orbitron)
            ?: error("Не удалось загрузить карту ORBITRON")
    }

    val cache = mapTextureCacheFile(context, style)
    if (cache.exists() && cache.length() > 1024L) {
        BitmapFactory.decodeFile(cache.absolutePath)?.let { return it }
        runCatching { cache.delete() }
    }

    val url = mapTextureUrl(style) ?: error("Неизвестный стиль карты: $style")
    val bytes = downloadBitmapBytes(url)
    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        ?: error("Источник $style вернул неподдерживаемое изображение")
    runCatching { cache.writeBytes(bytes) }
    return bmp
}

@Composable
private fun TutorApp(context: Context) {
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
    var records by remember { mutableStateOf(emptyList<TleRecord>()) }
    var selected by remember { mutableStateOf<TleRecord?>(null) }
    var sourceLabel by remember { mutableStateOf("Нет загруженного файла") }
    var status by remember { mutableStateOf("Откройте TLE/Kepler-файл или загрузите свежий список R4UAB") }
    var sourceAgeNowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var query by remember { mutableStateOf("") }
    var showPicker by remember { mutableStateOf(false) }
    var showTleSourceMenu by remember { mutableStateOf(false) }
    var showNetworkDiagnostics by remember { mutableStateOf(false) }
    var networkDiagnosticsText by remember { mutableStateOf("") }
    var networkDiagnosticsRunning by remember { mutableStateOf(false) }
    var manualCommandSending by remember { mutableStateOf(false) }
    var parkCommandSending by remember { mutableStateOf(false) }
    var mapStyle by remember {
        mutableStateOf(prefs.getString("map_style", "STANDARD") ?: "STANDARD")
    }
    var globeViewMode by remember {
        mutableStateOf(prefs.getString("globe_view_mode", "TRACK") ?: "TRACK")
    }
    var mapOrbitMode by remember {
        mutableStateOf(prefs.getString("map_orbit_mode", "SINGLE") ?: "SINGLE")
    }
    var showMapStyleMenu by remember { mutableStateOf(false) }
    var mapTexture by remember {
        mutableStateOf<Bitmap?>(BitmapFactory.decodeResource(context.resources, R.drawable.world_map))
    }
    var mapTextureStatus by remember { mutableStateOf("") }
    var keepScreenOn by remember {
        mutableStateOf(prefs.getBoolean("keep_screen_on", true))
    }
    var selectedPassCountdown by remember { mutableStateOf("AOS: расчёт…") }
    var selectedNextAosMs by remember { mutableStateOf<Long?>(null) }
    var selectedCurrentLosMs by remember { mutableStateOf<Long?>(null) }
    DisposableEffect(keepScreenOn) {
        val activity = context as? android.app.Activity
        if (keepScreenOn) {
            activity?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            if (keepScreenOn) {
                activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    LaunchedEffect(mapStyle) {
        mapTextureStatus = if (mapStyle == "STANDARD" || mapStyle == "CONTROL" || mapStyle == "POLITICAL COLOR" || mapStyle == "ORBITRON") "" else "Загрузка карты $mapStyle…"
        val loaded = withContext(Dispatchers.IO) {
            runCatching { loadMapTexture(context, mapStyle) }
        }
        loaded.onSuccess {
            mapTexture = it
            mapTextureStatus = ""
        }.onFailure { e ->
            mapTexture = BitmapFactory.decodeResource(context.resources, R.drawable.world_map)
            mapTextureStatus = "MAP $mapStyle: ${e.message ?: "ошибка загрузки"} • показана STANDARD"
        }
    }

    var observerLat by remember { mutableStateOf(prefs.getString("observer_lat", "55.75") ?: "55.75") }
    var observerLon by remember { mutableStateOf(prefs.getString("observer_lon", "37.62") ?: "37.62") }
    var observerAlt by remember { mutableStateOf(prefs.getString("observer_alt", "200") ?: "200") }
    var qthLocator by remember { mutableStateOf(prefs.getString("qth_locator", "") ?: "") }
    var radioMHz by remember { mutableStateOf("145.800") }
    var live by remember { mutableStateOf<LivePosition?>(null) }
    var track by remember { mutableStateOf(emptyList<GroundPoint>()) }
    var multiOrbitTracks by remember { mutableStateOf<Map<Int, List<GroundPoint>>>(emptyMap()) }
    var multiOrbitLive by remember { mutableStateOf<Map<Int, LivePosition>>(emptyMap()) }
    var page by remember { mutableStateOf("ORBIT") }
    var passes by remember { mutableStateOf(emptyList<ScheduledPass>()) }
    val passSelectionPrefsKey = "pass_selected_norads"

    // Restore immediately, before the saved TLE is loaded. This avoids the startup
    // race where an empty Compose state could overwrite the saved NORAD list.
    val initialPassSelectedNorads = remember {
        prefs.getStringSet(passSelectionPrefsKey, emptySet()).orEmpty()
            .mapNotNull { it.toIntOrNull() }
            .toSet()
    }
    var passSelectedNorads by remember {
        mutableStateOf(initialPassSelectedNorads)
    }

    // Persist only after state actually changes. Since the state starts from the
    // stored value, application startup no longer erases the saved selection.
    LaunchedEffect(passSelectedNorads) {
        val stored = prefs.getStringSet(passSelectionPrefsKey, emptySet()).orEmpty()
            .mapNotNull { it.toIntOrNull() }
            .toSet()
        if (stored != passSelectedNorads) {
            prefs.edit()
                .putStringSet(
                    passSelectionPrefsKey,
                    passSelectedNorads.map { it.toString() }.toSet()
                )
                .apply()
        }
    }

    // Refresh the visible TLE data age once per minute on every page.
    LaunchedEffect(Unit) {
        while (true) {
            sourceAgeNowMs = System.currentTimeMillis()
            delay(60_000L)
        }
    }
    var minPassElevation by remember { mutableStateOf("0") }
    var passHours by remember { mutableStateOf(prefs.getString("pass_hours", "24") ?: "24") }
    val gs232 = remember { Gs232UsbController(context) }
    val gs232Tcp = remember { Gs232TcpController(context) }
    var rotatorConnected by remember { mutableStateOf(false) }
    var rotatorStopActive by remember { mutableStateOf(false) }
    var rotatorConnectionUiState by remember { mutableStateOf("IDLE") }
    var rotatorTracking by remember { mutableStateOf(false) }
    var rotatorTransport by remember { mutableStateOf(prefs.getString("rotator_transport", "USB") ?: "USB") }
    var rotatorTcpHost by remember { mutableStateOf(prefs.getString("rotator_tcp_host", "192.168.4.1") ?: "192.168.4.1") }
    var rotatorTcpPort by remember { mutableStateOf(prefs.getString("rotator_tcp_port", "4533") ?: "4533") }
    var rotatorStatus by remember { mutableStateOf("ROTATOR: не подключено") }
    var rotatorFeedback by remember { mutableStateOf("AZ ---°  EL ---°") }
    var rotatorManualAz by remember { mutableStateOf("180") }
    var rotatorManualEl by remember { mutableStateOf("0") }
    var rotatorPeriodMs by remember { mutableStateOf(prefs.getString("rotator_period_ms", "1000") ?: "1000") }
    var rotatorMinEl by remember { mutableStateOf(prefs.getString("rotator_min_el", "0") ?: "0") }
    var rotatorStepDeg by remember { mutableStateOf(prefs.getString("rotator_step_deg", "3.0") ?: "3.0") }
    var rotatorMode by remember { mutableStateOf(prefs.getString("rotator_mode", "360") ?: "360") }
    var rotatorParkAz by remember { mutableStateOf(prefs.getString("rotator_park_az", "0") ?: "0") }
    var rotatorParkEl by remember { mutableStateOf(prefs.getString("rotator_park_el", "0") ?: "0") }
    var rotatorParkAfterLos by remember { mutableStateOf(prefs.getBoolean("rotator_park_after_los", false)) }
    var rotatorActualAz by remember { mutableStateOf<Double?>(null) }
    var radarPreview by remember { mutableStateOf<RadarPreview?>(null) }

    // Countdown for the satellite currently selected in the main selector.
    // During an active pass show time remaining to LOS. After LOS switch to
    // the next future AOS. Horizon is the geometric EL = 0° boundary.
    LaunchedEffect(selected?.norad, observerLat, observerLon, observerAlt) {
        selectedNextAosMs = null
        selectedCurrentLosMs = null
        selectedPassCountdown = "AOS: расчёт…"
        var lastSearchMs = 0L

        while (true) {
            val recForPass = selected
            val lat = observerLat.toDoubleOrNull()
            val lon = observerLon.toDoubleOrNull()
            val alt = observerAlt.toDoubleOrNull() ?: 0.0
            val nowMs = System.currentTimeMillis()

            if (recForPass == null) {
                selectedNextAosMs = null
                selectedCurrentLosMs = null
                selectedPassCountdown = "AOS: спутник не выбран"
            } else if (lat == null || lon == null || lat !in -90.0..90.0 || lon !in -180.0..180.0) {
                selectedNextAosMs = null
                selectedCurrentLosMs = null
                selectedPassCountdown = "AOS: проверьте QTH"
            } else {
                val knownLos = selectedCurrentLosMs
                val knownAos = selectedNextAosMs
                val needSearch =
                    (knownLos == null || knownLos <= nowMs) &&
                    (knownAos == null || knownAos <= nowMs)

                if (needSearch && nowMs - lastSearchMs >= 30_000L) {
                    lastSearchMs = nowMs
                    selectedPassCountdown = "AOS: расчёт…"

                    val passState = withContext(Dispatchers.Default) {
                        runCatching {
                            val posNow = Sgp4Engine.position(
                                recForPass,
                                Date(nowMs),
                                lat,
                                lon,
                                alt
                            )
                            val nextPasses = PassPredictor.nextPasses(
                                rec = recForPass,
                                observerLat = lat,
                                observerLon = lon,
                                observerAltM = alt,
                                start = Date(nowMs),
                                horizonHours = 72,
                                minElevationDeg = 0.0,
                                maxPasses = 20
                            )

                            if (posNow.elevationDeg >= 0.0) {
                                // PassPredictor restores the real AOS when calculation
                                // starts inside a pass, so the first pass contains the
                                // current pass and its real LOS.
                                val currentPass = nextPasses.firstOrNull {
                                    it.aos.time <= nowMs && it.los.time > nowMs
                                } ?: nextPasses.firstOrNull {
                                    it.los.time > nowMs
                                }
                                Pair(currentPass?.los?.time, null)
                            } else {
                                val nextAos = nextPasses
                                    .firstOrNull { it.aos.time > nowMs + 500L }
                                    ?.aos
                                    ?.time
                                Pair(null, nextAos)
                            }
                        }.getOrNull()
                    }

                    selectedCurrentLosMs = passState?.first
                    selectedNextAosMs = passState?.second

                    if (selectedCurrentLosMs == null && selectedNextAosMs == null) {
                        selectedPassCountdown = "AOS: не найден в ближайшие 72 ч"
                    }
                }

                val losMs = selectedCurrentLosMs
                val aosMs = selectedNextAosMs

                when {
                    losMs != null && losMs > nowMs -> {
                        selectedPassCountdown = "До конца пролёта ${formatCountdown(losMs - nowMs)}"
                    }
                    losMs != null && losMs <= nowMs -> {
                        // The current pass has just ended. Force a new search for
                        // the next AOS on the next iteration.
                        selectedCurrentLosMs = null
                        selectedNextAosMs = null
                        lastSearchMs = 0L
                        selectedPassCountdown = "AOS: расчёт…"
                    }
                    aosMs != null && aosMs > nowMs -> {
                        selectedPassCountdown = formatAosCountdown(aosMs, nowMs)
                    }
                    aosMs != null && aosMs <= nowMs -> {
                        // AOS was reached. Force pass re-evaluation so the display
                        // changes immediately to the current-pass LOS countdown.
                        selectedNextAosMs = null
                        selectedCurrentLosMs = null
                        lastSearchMs = 0L
                        selectedPassCountdown = "AOS: расчёт…"
                    }
                }
            }

            delay(1_000L)
        }
    }

    fun loadText(text: String, label: String, persist: Boolean = true) {
        val parsed = TleParser.parse(text)
        records = parsed
        val preferredNorad = prefs.getInt("selected_norad", -1)
        selected = parsed.firstOrNull { it.norad == preferredNorad } ?: parsed.firstOrNull()
        val validNorads = parsed.map { it.norad }.toSet()
        val filteredPassSelection = passSelectedNorads.intersect(validNorads)
        passSelectedNorads = when {
            filteredPassSelection.isNotEmpty() -> filteredPassSelection
            initialPassSelectedNorads.isNotEmpty() -> {
                // Saved satellites are absent from this TLE source. Do not silently
                // replace the user's multi-selection with an arbitrary satellite.
                emptySet()
            }
            else -> selected?.let { setOf(it.norad) } ?: emptySet()
        }
        sourceLabel = label
        sourceAgeNowMs = System.currentTimeMillis()
        status = if (parsed.isEmpty()) "TLE не найдены" else "Загружено спутников: ${parsed.size}"
        live = null; passes = emptyList()
        if (persist && parsed.isNotEmpty()) {
            runCatching { saveTleToInternal(context, text) }
            prefs.edit().putString("tle_source_label", label).apply()
        }
    }

    LaunchedEffect(Unit) {
        val saved = withContext(Dispatchers.IO) { loadSavedTle(context) }
        if (saved != null) {
            val label = prefs.getString("tle_source_label", "Сохранённый TLE") ?: "Сохранённый TLE"
            loadText(saved, "$label • сохранено", persist = false)
            status = "Восстановлен сохранённый TLE: ${records.size} спутников"
        }
    }

    // AOS / LOS acoustic alerts. This watcher lives at app level, so it keeps
    // watching the already calculated pass list even when another page is open.
    LaunchedEffect(passes) {
        if (passes.isEmpty()) return@LaunchedEffect

        var previousMs = System.currentTimeMillis()
        while (true) {
            delay(250)
            val nowMs = System.currentTimeMillis()

            // Do not replay stale events after a very long suspension/restart.
            // Normal screen-off operation on devices that keep the app running
            // continues to trigger at the actual crossing.
            val timelyWindowMs = 15_000L

            val aosCrossed = passes.firstOrNull {
                previousMs < it.pass.aos.time &&
                    it.pass.aos.time <= nowMs &&
                    nowMs - it.pass.aos.time <= timelyWindowMs
            }
            if (aosCrossed != null) {
                playPassAudioSignal(isAos = true)   // rising custom chime
            }

            val losCrossed = passes.firstOrNull {
                previousMs < it.pass.los.time &&
                    it.pass.los.time <= nowMs &&
                    nowMs - it.pass.los.time <= timelyWindowMs
            }
            if (losCrossed != null) {
                playPassAudioSignal(isAos = false)  // falling custom chime
            }

            previousMs = nowMs
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            rotatorTracking = false
            gs232.close()
            gs232Tcp.close()
        }
    }


    LaunchedEffect(
        selected?.norad,
        selected?.line1,
        selected?.line2,
        sourceLabel
    ) {
        val rec = selected
        if (rec == null) {
            live = null
            track = emptyList()
            radarPreview = null
        } else {
            // Keep the existing orbit visible while the refreshed track is calculated.
            val refreshedTrack = withContext(Dispatchers.Default) { Sgp4Engine.track(rec) }
            if (refreshedTrack.isNotEmpty()) {
                track = refreshedTrack
            }
        }
    }

    // Current orbit of every selected satellite: exactly one orbital period
    // centered on "now". This is NOT a list of future passes.
    LaunchedEffect(page, passSelectedNorads, selected?.norad, sourceLabel) {
        if (page != "ORBIT") return@LaunchedEffect

        while (true) {
            val activeNorad = selected?.norad
            val targetNorads = buildSet {
                addAll(passSelectedNorads)
                activeNorad?.let { add(it) }
            }
            val targetRecords = records.filter { it.norad in targetNorads }
            val now = Date()

            multiOrbitTracks = withContext(Dispatchers.Default) {
                targetRecords.associate { sat ->
                    sat.norad to runCatching {
                        Sgp4Engine.track(sat, center = now, points = 140)
                    }.getOrDefault(emptyList())
                }
            }

            delay(60_000L)
        }
    }

    // Current positions of the same satellites. Positions are refreshed quickly,
    // while the heavier full-orbit tracks above are refreshed only once per minute.
    LaunchedEffect(page, passSelectedNorads, selected?.norad, observerLat, observerLon, observerAlt, sourceLabel) {
        if (page != "ORBIT") return@LaunchedEffect

        while (true) {
            val activeNorad = selected?.norad
            val targetNorads = buildSet {
                addAll(passSelectedNorads)
                activeNorad?.let { add(it) }
            }
            val targetRecords = records.filter { it.norad in targetNorads }
            val la = observerLat.toDoubleOrNull()
            val lo = observerLon.toDoubleOrNull()
            val al = observerAlt.toDoubleOrNull() ?: 0.0

            multiOrbitLive = if (la != null && lo != null) {
                withContext(Dispatchers.Default) {
                    targetRecords.mapNotNull { sat ->
                        runCatching {
                            sat.norad to Sgp4Engine.position(sat, Date(), la, lo, al)
                        }.getOrNull()
                    }.toMap()
                }
            } else {
                emptyMap()
            }

            delay(1_000L)
        }
    }

    LaunchedEffect(page, selected, observerLat, observerLon, observerAlt) {
        if (page != "ORBIT") return@LaunchedEffect
        val rec = selected ?: return@LaunchedEffect
        while (true) {
            val la = observerLat.toDoubleOrNull()
            val lo = observerLon.toDoubleOrNull()
            val al = observerAlt.toDoubleOrNull() ?: 0.0
            if (la != null && lo != null) {
                live = runCatching {
                    withContext(Dispatchers.Default) { Sgp4Engine.position(rec, Date(), la, lo, al) }
                }.getOrNull()
            }
            delay(1000)
        }
    }

    LaunchedEffect(page, selected, observerLat, observerLon, observerAlt) {
        if (page != "ORBIT") return@LaunchedEffect
        val rec = selected ?: return@LaunchedEffect
        while (true) {
            val la = observerLat.toDoubleOrNull()
            val lo = observerLon.toDoubleOrNull()
            val al = observerAlt.toDoubleOrNull() ?: 0.0
            radarPreview = if (la != null && lo != null) {
                runCatching {
                    withContext(Dispatchers.Default) { computeRadarPreview(rec, la, lo, al, Date()) }
                }.getOrNull()
            } else null
            delay(30000)
        }
    }

    // Continuous GS-232 feedback polling.
    // ROTATOR FEEDBACK must remain live not only during AUTO TRACK, but also
    // while PARK and manual Waaa eee commands are being executed.
    LaunchedEffect(rotatorConnected, rotatorTransport) {
        if (!rotatorConnected) return@LaunchedEffect
        while (rotatorConnected) {
            val qr = runCatching {
                if (rotatorTransport == "TCP") {
                    val r = gs232Tcp.queryAngles()
                    r.first?.let { Gs232UsbController.Angles(it.azimuthDeg, it.elevationDeg) } to r.second
                } else {
                    gs232.queryAngles()
                }
            }.getOrNull()

            qr?.first?.let {
                rotatorActualAz = it.azimuthDeg
                rotatorFeedback = "AZ ${"%.0f".format(it.azimuthDeg)}°  EL ${"%.0f".format(it.elevationDeg)}°"
            }

            // Frequent enough for visibly moving pointers, but not excessive for GS-232.
            delay(500L)
        }
    }

    LaunchedEffect(rotatorTracking, rotatorConnected, selected, observerLat, observerLon, observerAlt, rotatorPeriodMs, rotatorMinEl, rotatorStepDeg, rotatorTransport, rotatorMode, rotatorParkAz, rotatorParkEl, rotatorParkAfterLos) {
        if (!rotatorTracking || !rotatorConnected) return@LaunchedEffect
        val rec = selected ?: return@LaunchedEffect
        var heldTargetAz: Double? = null
        var heldTargetEl: Double? = null
        var belowLimit = false
        var wasAboveHorizon = false

        fun normalizedAzimuth(az: Double): Double {
            var a = az % 360.0
            if (a < 0.0) a += 360.0
            return a
        }

        fun mapAzimuthForRotator(skyAz: Double, referenceAz: Double?): Double {
            val base = normalizedAzimuth(skyAz)
            if (rotatorMode != "450") return base
            val candidates = buildList {
                add(base)
                val extended = base + 360.0
                if (extended <= 450.0) add(extended)
            }
            val ref = referenceAz ?: return candidates.first()
            return candidates.minByOrNull { abs(it - ref) } ?: base
        }

        fun azDifference(a: Double, b: Double): Double {
            return if (rotatorMode == "450") abs(a - b) else {
                val d = abs(a - b) % 360.0
                minOf(d, 360.0 - d)
            }
        }

        suspend fun sendTarget(az: Double, el: Double): Boolean =
            if (rotatorTransport == "TCP") gs232Tcp.setTarget(az, el) else gs232.setTarget(az, el)
        suspend fun stopRotator(): Boolean =
            if (rotatorTransport == "TCP") gs232Tcp.stop() else gs232.stop()

        while (rotatorTracking && rotatorConnected) {
            val la = observerLat.toDoubleOrNull()
            val lo = observerLon.toDoubleOrNull()
            val al = observerAlt.toDoubleOrNull() ?: 0.0
            val minEl = rotatorMinEl.toDoubleOrNull()?.coerceIn(0.0, 89.0) ?: 0.0
            val requestedStep = rotatorStepDeg.toDoubleOrNull() ?: 3.0
            val step = listOf(1.0, 3.0, 5.0, 7.0, 10.0).minByOrNull { abs(it - requestedStep) } ?: 3.0
            if (la == null || lo == null) {
                rotatorStatus = "Неверные координаты наблюдателя"
                rotatorTracking = false
                break
            }
            val p = runCatching { withContext(Dispatchers.Default) { Sgp4Engine.position(rec, Date(), la, lo, al) } }.getOrNull()
            if (p == null) {
                rotatorStatus = "Ошибка SGP4 во время автослежения"
            } else {
                live = p

                // Optional PARK AFTER LOS: trigger once when the tracked satellite
                // crosses from above the geometric horizon to below 0° elevation.
                if (p.elevationDeg >= 0.0) {
                    wasAboveHorizon = true
                } else if (rotatorParkAfterLos && wasAboveHorizon) {
                    val parkAz = rotatorParkAz.toDoubleOrNull()
                    val parkEl = rotatorParkEl.toDoubleOrNull()
                    val maxAz = if (rotatorMode == "450") 450.0 else 360.0
                    if (parkAz != null && parkEl != null && parkAz in 0.0..maxAz && parkEl in 0.0..180.0) {
                        val ok = runCatching { sendTarget(parkAz, parkEl) }.getOrDefault(false)
                        rotatorStatus = if (ok) {
                            "LOS • PARK → W%03d %03d".format(parkAz.roundToInt(), parkEl.roundToInt())
                        } else {
                            "LOS • ошибка PARK"
                        }
                    } else {
                        rotatorStatus = "LOS • неверная PARK позиция"
                    }
                    rotatorTracking = false
                    break
                }

                val skyAz = normalizedAzimuth(p.azimuthDeg)
                val referenceAz = heldTargetAz ?: rotatorActualAz
                val az = mapAzimuthForRotator(skyAz, referenceAz)
                val el = p.elevationDeg.coerceIn(-90.0, 180.0)
                if (p.elevationDeg >= minEl) {
                    if (belowLimit) {
                        heldTargetAz = null
                        heldTargetEl = null
                        belowLimit = false
                    }

                    if (heldTargetAz == null || heldTargetEl == null) {
                        // First command after TRACK start / AOS initializes both axes.
                        val cmdAz = az.roundToInt().toDouble()
                        val cmdEl = el.coerceAtLeast(0.0).roundToInt().toDouble()
                        val ok = runCatching { sendTarget(cmdAz, cmdEl) }.getOrDefault(false)
                        if (ok) {
                            heldTargetAz = az
                            heldTargetEl = el
                            rotatorStatus = "TRACK ${rec.name}: INIT W%03d %03d • step %.0f°"
                                .format(cmdAz.roundToInt(), cmdEl.roundToInt(), step)
                        } else rotatorStatus = "Ошибка передачи команды W"
                    } else {
                        val daz = azDifference(az, heldTargetAz!!)
                        val del = abs(el - heldTargetEl!!)
                        val updateAz = daz >= step
                        val updateEl = del >= step

                        if (updateAz || updateEl) {
                            // IMPORTANT: each axis advances independently. The other target is held.
                            val nextAz = if (updateAz) az else heldTargetAz!!
                            val nextEl = if (updateEl) el.coerceAtLeast(0.0) else heldTargetEl!!.coerceAtLeast(0.0)
                            val cmdAz = nextAz.roundToInt()
                            val cmdEl = nextEl.roundToInt()
                            val ok = runCatching { sendTarget(cmdAz.toDouble(), cmdEl.toDouble()) }.getOrDefault(false)
                            if (ok) {
                                if (updateAz) heldTargetAz = az
                                if (updateEl) heldTargetEl = el
                                val changed = buildList {
                                    if (updateAz) add("AZ")
                                    if (updateEl) add("EL")
                                }.joinToString("+")
                                rotatorStatus = "TRACK ${rec.name}: $changed → W%03d %03d • ΔAZ %.1f° ΔEL %.1f° • step %.0f°"
                                    .format(cmdAz, cmdEl, daz, del, step)
                            } else rotatorStatus = "Ошибка передачи команды W"
                        } else {
                            rotatorStatus = "TRACK ${rec.name}: HOLD AZ %.0f° EL %.0f° • ΔAZ %.1f° ΔEL %.1f° • step %.0f°"
                                .format(heldTargetAz, heldTargetEl, daz, del, step)
                        }
                    }
                } else {
                    if (!belowLimit) {
                        runCatching { stopRotator() }
                        belowLimit = true
                    }
                    rotatorStatus = "Спутник ниже ${"%.1f".format(minEl)}°: STOP • EL=${"%.1f".format(p.elevationDeg)}°"
                }

            }
            delay((rotatorPeriodMs.toLongOrNull() ?: 1000L).coerceIn(500L, 10000L))
        }
    }

    fun updateDynamics() {
        val rec = selected ?: return
        scope.launch {
            runCatching {
                withContext(Dispatchers.Default) {
                    val lat = observerLat.toDoubleOrNull() ?: 0.0
                    val lon = observerLon.toDoubleOrNull() ?: 0.0
                    val alt = observerAlt.toDoubleOrNull() ?: 0.0
                    Sgp4Engine.position(rec, Date(), lat, lon, alt) to Sgp4Engine.track(rec)
                }
            }.onSuccess { (p, t) -> live = p; track = t; status = "SGP4 обновлён: ${Date()}" }
                .onFailure { status = "Ошибка SGP4: ${it.message}" }
        }
    }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)!!.bufferedReader().readText() } }
                .onSuccess { loadText(it, "Файл: ${uri.lastPathSegment ?: "TLE"}") }
                .onFailure { status = "Ошибка файла: ${it.message}" }
        }
    }

    fun applyLocatedPosition(location: Location) {
        observerLat = "%.6f".format(java.util.Locale.US, location.latitude)
        observerLon = "%.6f".format(java.util.Locale.US, location.longitude)
        if (location.hasAltitude()) observerAlt = "%.0f".format(java.util.Locale.US, location.altitude)
        prefs.edit()
            .putString("observer_lat", observerLat)
            .putString("observer_lon", observerLon)
            .putString("observer_alt", observerAlt)
            .putString("qth_locator", latLonToMaidenhead(location.latitude, location.longitude, 6))
            .apply()
        qthLocator = latLonToMaidenhead(location.latitude, location.longitude, 6)
        status = "Locator: %.6f°, %.6f°%s".format(
            java.util.Locale.US, location.latitude, location.longitude,
            if (location.hasAltitude()) " • alt %.0f m".format(java.util.Locale.US, location.altitude) else ""
        )
        updateDynamics()
    }

    fun locateNow() {
        status = "Locator: определение местоположения…"
        requestBestLocation(
            context = context,
            onSuccess = { applyLocatedPosition(it) },
            onError = { status = it }
        )
    }

    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) locateNow() else status = "Locator: разрешение на местоположение не предоставлено"
    }

    val mainScrollState = rememberScrollState()

    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(mainScrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Image(
                    painter = painterResource(id = ua1cfm.keplertutor.R.drawable.kepler_orbit_tutor_icon_master),
                    contentDescription = "Kepler Orbit icon",
                    modifier = Modifier.size(58.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text("Kepler Orbit", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Accent)
                    Text("v0.1.89 • SGP4 • GS-232B", fontSize = 11.sp, color = Color.LightGray)
                }
            }
            Spacer(Modifier.height(2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "KEEP SCREEN ON",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (keepScreenOn) Good else Color.LightGray,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = keepScreenOn,
                    onCheckedChange = {
                        keepScreenOn = it
                        prefs.edit().putBoolean("keep_screen_on", it).apply()
                    }
                )
            }
            Spacer(Modifier.height(2.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { openFile.launch(arrayOf("text/plain", "*/*")) }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)) { ControlButtonText("OPEN TLE", fontSize = 12.sp) }
                Box(modifier = Modifier.weight(1f)) {
                    Button(
                        onClick = { showTleSourceMenu = true },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)
                    ) { ControlButtonText("DOWNLOAD TLE", fontSize = 12.sp) }

                    DropdownMenu(
                        expanded = showTleSourceMenu,
                        onDismissRequest = { showTleSourceMenu = false }
                    ) {
                        TLE_SOURCE_OPTIONS.forEach { src ->
                            DropdownMenuItem(
                                text = { Text(src.menuLabel, fontSize = 12.sp) },
                                onClick = {
                                    showTleSourceMenu = false
                                    scope.launch {
                                        status = "Загрузка TLE: ${src.menuLabel}…"
                                        runCatching {
                                            withContext(Dispatchers.IO) { downloadTleSource(src.id) }
                                        }.onSuccess { result ->
                                            loadText(result.text, result.sourceLabel, persist = true)
                                            status = "TLE обновлены и сохранены: ${result.sourceLabel}"
                                        }.onFailure { e ->
                                            status = "Ошибка загрузки TLE: ${e.message}"
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
                OutlinedButton(onClick = {
                    deleteSavedTle(context)
                    prefs.edit().remove("tle_source_label").remove("selected_norad").apply()
                    records = emptyList(); selected = null; passSelectedNorads = emptySet(); live = null; track = emptyList(); passes = emptyList()
                    sourceLabel = "Нет загруженного файла"
                    sourceAgeNowMs = System.currentTimeMillis()
                    status = "Сохранённый TLE удалён"
                }, modifier = Modifier.weight(0.85f).heightIn(min = 50.dp), contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)) { ControlButtonText("DELETE TLE", fontSize = 11.sp) }
            }
            Spacer(Modifier.height(6.dp))
            Button(
                onClick = {
                    showNetworkDiagnostics = true
                    networkDiagnosticsRunning = true
                    networkDiagnosticsText = "Проверка сети…"
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { runNetworkDiagnostics() }
                        networkDiagnosticsText = result
                        networkDiagnosticsRunning = false
                    }
                },
                modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
            ) {
                ControlButtonText(
                    if (networkDiagnosticsRunning) "NETWORK TEST…" else "NETWORK DIAGNOSTICS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            if (showNetworkDiagnostics) {
                Spacer(Modifier.height(6.dp))
                CardBox("NETWORK DIAGNOSTICS") {
                    Text(
                        networkDiagnosticsText,
                        fontSize = 11.sp,
                        color = Color.LightGray
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = { showNetworkDiagnostics = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ControlButtonText("CLOSE", fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(sourceLabel, fontSize = 12.sp, color = Good)
            if (records.isNotEmpty()) {
                Text(
                    "С момента данных файла: ${formatTleFileDataAge(records, sourceAgeNowMs)}",
                    fontSize = 11.sp,
                    color = Color.LightGray,
                    maxLines = 1
                )
            }
            Text(status, fontSize = 11.sp, color = Color.Gray, maxLines = 6)
            Spacer(Modifier.height(6.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (page == "ORBIT") Button(onClick = { page = "ORBIT" }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { ControlButtonText("ORBIT / MAP", fontSize = 12.sp) }
                else OutlinedButton(onClick = { page = "ORBIT" }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { ControlButtonText("ORBIT / MAP", fontSize = 12.sp) }
                if (page == "PASSES") Button(onClick = { page = "PASSES" }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { ControlButtonText("PASSES", fontSize = 12.sp) }
                else OutlinedButton(onClick = { page = "PASSES" }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { ControlButtonText("PASSES", fontSize = 12.sp) }
                if (page == "ROTATOR") Button(onClick = { page = "ROTATOR" }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { ControlButtonText("ROTATOR", fontSize = 12.sp) }
                else OutlinedButton(onClick = { page = "ROTATOR" }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { ControlButtonText("ROTATOR", fontSize = 12.sp) }
            }
            Spacer(Modifier.height(4.dp))

            selected?.let { rec ->
                OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                    ControlButtonText("SATELLITE: ${rec.name}   •   NORAD ${rec.norad}", fontSize = 11.sp)
                }
                Spacer(Modifier.height(2.dp))
                if (page == "PASSES") {
                    PassScheduleScreen(
                        records = records,
                        selectedNorads = passSelectedNorads,
                        onSelectedNoradsChange = { newSelection ->
                            passSelectedNorads = newSelection
                            prefs.edit()
                                .putStringSet(
                                    passSelectionPrefsKey,
                                    newSelection.map { it.toString() }.toSet()
                                )
                                .apply()
                        },
                        observerLat = observerLat,
                        observerLon = observerLon,
                        observerAlt = observerAlt,
                        minElevation = minPassElevation,
                        onMinElevationChange = { minPassElevation = it },
                        hours = passHours,
                        onHoursChange = {
                            passHours = it
                            prefs.edit().putString("pass_hours", it).apply()
                        },
                        passes = passes,
                        mainScrollState = mainScrollState,
                        rotatorFeedback = rotatorFeedback,
                        trackingNorad = selected?.norad,
                        onSelectTrackingSatellite = { sat ->
                            selected = sat
                            prefs.edit().putInt("selected_norad", sat.norad).apply()
                            live = null
                            status = "Цель сопровождения: ${sat.name} • NORAD ${sat.norad}"
                        },
                        onCalculate = {
                            val la = observerLat.toDoubleOrNull()
                            val lo = observerLon.toDoubleOrNull()
                            val al = observerAlt.toDoubleOrNull() ?: 0.0
                            val minEl = minPassElevation.toDoubleOrNull()?.coerceIn(0.0, 89.0) ?: 0.0
                            val hours = passHours.toIntOrNull()?.coerceIn(1, 168) ?: 24
                            if (la == null || lo == null) {
                                status = "Неверные координаты наблюдателя"
                            } else {
                                val selectedRecords = records.filter { it.norad in passSelectedNorads }
                                if (selectedRecords.isEmpty()) {
                                    status = "Выберите хотя бы один спутник для PASS"
                                } else scope.launch {
                                    status = "Расчёт пролётов: ${selectedRecords.size} спутн.…"
                                    runCatching {
                                        withContext(Dispatchers.Default) {
                                            selectedRecords.flatMap { sat ->
                                                PassPredictor.nextPasses(sat, la, lo, al, Date(), hours, minEl, 20)
                                                    .map { pass -> ScheduledPass(sat, pass) }
                                            }.sortedBy { it.pass.aos.time }
                                        }
                                    }.onSuccess {
                                        passes = it
                                        status = if (it.isEmpty()) {
                                            "За $hours ч подходящих пролётов не найдено"
                                        } else {
                                            "Рассчитано пролётов: ${it.size} • спутников ${selectedRecords.size} • $hours ч"
                                        }
                                    }.onFailure { status = "Ошибка расчёта пролётов: ${it.message}" }
                                }
                            }
                        }
                    )
                } else if (page == "ROTATOR") {
                    RotatorScreen(
                        rec = rec,
                        live = live,
                        passCountdown = selectedPassCountdown,
                        connected = rotatorConnected,
                        connectionUiState = rotatorConnectionUiState,
                        stopActive = rotatorStopActive,
                        tracking = rotatorTracking,
                        status = rotatorStatus,
                        feedback = rotatorFeedback,
                        manualAz = rotatorManualAz,
                        manualEl = rotatorManualEl,
                        periodMs = rotatorPeriodMs,
                        minElevation = rotatorMinEl,
                        stepDeg = rotatorStepDeg,
                        mode = rotatorMode,
                        parkAz = rotatorParkAz,
                        parkEl = rotatorParkEl,
                        parkAfterLos = rotatorParkAfterLos,
                        manualSending = manualCommandSending,
                        parkSending = parkCommandSending,
                        transport = rotatorTransport,
                        tcpHost = rotatorTcpHost,
                        tcpPort = rotatorTcpPort,
                        onTransportChange = {
                            if (it != rotatorTransport) {
                                rotatorTracking = false
                                gs232.close(); gs232Tcp.close()
                                rotatorConnected = false
                                rotatorConnectionUiState = "IDLE"
                                rotatorFeedback = "AZ ---°  EL ---°"
                                rotatorActualAz = null
                                rotatorTransport = it
                                prefs.edit().putString("rotator_transport", it).apply()
                                rotatorStatus = if (it == "TCP") "TCP GS-232: не подключено" else "USB/OTG: не подключено"
                            }
                        },
                        onTcpHostChange = { rotatorTcpHost = it; prefs.edit().putString("rotator_tcp_host", it).apply() },
                        onTcpPortChange = { rotatorTcpPort = it; prefs.edit().putString("rotator_tcp_port", it).apply() },
                        onManualAzChange = { rotatorManualAz = it },
                        onManualElChange = { rotatorManualEl = it },
                        onPeriodChange = { rotatorPeriodMs = it; prefs.edit().putString("rotator_period_ms", it).apply() },
                        onMinElevationChange = { rotatorMinEl = it; prefs.edit().putString("rotator_min_el", it).apply() },
                        onStepDegChange = { rotatorStepDeg = it; prefs.edit().putString("rotator_step_deg", it).apply() },
                        onParkAzChange = { rotatorParkAz = it; prefs.edit().putString("rotator_park_az", it).apply() },
                        onParkElChange = { rotatorParkEl = it; prefs.edit().putString("rotator_park_el", it).apply() },
                        onParkAfterLosChange = {
                            rotatorParkAfterLos = it
                            prefs.edit().putBoolean("rotator_park_after_los", it).apply()
                        },
                        onRawUsbTest = { rotatorStatus = gs232.rawUsbDiagnostics() },
                        onConnect = {
                            scope.launch {
                                if (rotatorTransport == "TCP") {
                                    val port = rotatorTcpPort.toIntOrNull()?.coerceIn(1, 65535) ?: 4533
                                    val result = gs232Tcp.connect(rotatorTcpHost, port)
                                    if (result.isSuccess) {
                                        rotatorConnected = true
                                        rotatorConnectionUiState = "CONNECTED"
                                        rotatorStatus = "TCP GS-232 подключено: ${result.getOrNull()}"
                                        val modeOk = runCatching { if (rotatorMode == "450") gs232Tcp.set450Mode() else gs232Tcp.set360Mode() }.getOrDefault(false)
                                        if (!modeOk) rotatorStatus = "TCP подключено, но не удалось установить P${if (rotatorMode == "450") "45" else "36"}"
                                        val qr = runCatching { gs232Tcp.queryAngles() }.getOrNull()
                                        qr?.first?.let {
                    rotatorActualAz = it.azimuthDeg
                    rotatorFeedback = "AZ ${"%.0f".format(it.azimuthDeg)}°  EL ${"%.0f".format(it.elevationDeg)}°"
                }
                                    } else {
                                        rotatorConnected = false
                                        rotatorConnectionUiState = "IDLE"
                                        rotatorStatus = "TCP GS-232 ошибка: ${result.exceptionOrNull()?.message ?: "connection failed"}"
                                    }
                                } else {
                                    when (val cr = withContext(Dispatchers.IO) { gs232.connectOrRequestPermission(9600) }) {
                                        is Gs232UsbController.ConnectResult.Connected -> {
                                            rotatorConnected = true
                                            rotatorConnectionUiState = "CONNECTED"
                                            rotatorStatus = "USB подключено: ${cr.deviceName}"
                                            val modeOk = runCatching { if (rotatorMode == "450") gs232.set450Mode() else gs232.set360Mode() }.getOrDefault(false)
                                            if (!modeOk) rotatorStatus = "USB подключено, но не удалось установить P${if (rotatorMode == "450") "45" else "36"}"
                                            val qr = runCatching { gs232.queryAngles() }.getOrNull()
                                            qr?.first?.let {
                    rotatorActualAz = it.azimuthDeg
                    rotatorFeedback = "AZ ${"%.0f".format(it.azimuthDeg)}°  EL ${"%.0f".format(it.elevationDeg)}°"
                }
                                        }
                                        is Gs232UsbController.ConnectResult.PermissionRequested -> rotatorStatus = "Запрошено USB-разрешение для ${cr.deviceName}. После ALLOW нажмите CONNECT ещё раз."
                                        is Gs232UsbController.ConnectResult.Error -> { rotatorConnected = false; rotatorConnectionUiState = "IDLE"; rotatorStatus = cr.message }
                                    }
                                }
                            }
                        },
                        onDisconnect = { rotatorTracking = false; gs232.close(); gs232Tcp.close(); rotatorConnected = false; rotatorConnectionUiState = "DISCONNECTED"; rotatorActualAz = null; rotatorStatus = "ROTATOR: отключено"; rotatorFeedback = "AZ ---°  EL ---°" },
                        onQuery = {
                            scope.launch {
                                if (rotatorTransport == "TCP") {
                                    val qr = runCatching { gs232Tcp.queryAngles() }.getOrNull()
                                    if (qr == null) rotatorStatus = "Ошибка C2" else {
                                        qr.first?.let {
                                            rotatorActualAz = it.azimuthDeg
                                            rotatorFeedback = "AZ ${"%.0f".format(it.azimuthDeg)}°  EL ${"%.0f".format(it.elevationDeg)}°"
                                        }
                                        rotatorStatus = if (qr.second.isBlank()) "C2: нет ответа" else "C2: ${qr.second}"
                                    }
                                } else {
                                    val qr = runCatching { gs232.queryAngles() }.getOrNull()
                                    if (qr == null) rotatorStatus = "Ошибка C2" else {
                                        qr.first?.let {
                                            rotatorActualAz = it.azimuthDeg
                                            rotatorFeedback = "AZ ${"%.0f".format(it.azimuthDeg)}°  EL ${"%.0f".format(it.elevationDeg)}°"
                                        }
                                        rotatorStatus = if (qr.second.isBlank()) "C2: нет ответа" else "C2: ${qr.second}"
                                    }
                                }
                            }
                        },
                        onStop = {
                            scope.launch {
                                rotatorStopActive = true
                                val ok = runCatching {
                                    if (rotatorTransport == "TCP") gs232Tcp.stop() else gs232.stop()
                                }.getOrDefault(false)
                                rotatorTracking = false
                                rotatorStatus = if (ok) "STOP (S) отправлен" else "Ошибка STOP (S)"
                                delay(500)
                                rotatorStopActive = false
                            }
                        },
                        onManualGo = {
                            val az = rotatorManualAz.toDoubleOrNull()
                            val el = rotatorManualEl.toDoubleOrNull()
                            val maxAz = if (rotatorMode == "450") 450.0 else 360.0
                            if (az == null || el == null || az !in 0.0..maxAz || el !in 0.0..180.0) {
                                rotatorStatus = "Manual target: AZ 0…${maxAz.toInt()}°, EL 0…180°"
                            } else {
                                manualCommandSending = true
                                scope.launch {
                                    try {
                                        val ok = runCatching {
                                            if (rotatorTransport == "TCP") gs232Tcp.setTarget(az, el)
                                            else gs232.setTarget(az, el)
                                        }.getOrDefault(false)

                                        if (ok) {
                                            val qr = runCatching {
                                                if (rotatorTransport == "TCP") {
                                                    val r = gs232Tcp.queryAngles()
                                                    r.first?.let {
                                                        Gs232UsbController.Angles(it.azimuthDeg, it.elevationDeg)
                                                    } to r.second
                                                } else {
                                                    gs232.queryAngles()
                                                }
                                            }.getOrNull()

                                            qr?.first?.let {
                                                rotatorActualAz = it.azimuthDeg
                                                rotatorFeedback = "AZ ${"%.0f".format(it.azimuthDeg)}°  EL ${"%.0f".format(it.elevationDeg)}°"
                                            }
                                            rotatorStatus = "Manual W%03d %03d отправлена".format(
                                                az.roundToInt(), el.roundToInt()
                                            )
                                        } else {
                                            rotatorStatus = "Ошибка manual W"
                                        }
                                    } finally {
                                        delay(400)
                                        manualCommandSending = false
                                    }
                                }
                            }
                        },
                        onPark = {
                            val az = rotatorParkAz.toDoubleOrNull()
                            val el = rotatorParkEl.toDoubleOrNull()
                            val maxAz = if (rotatorMode == "450") 450.0 else 360.0
                            if (!rotatorConnected) {
                                rotatorStatus = "Сначала подключите GS-232 контроллер"
                            } else if (az == null || el == null || az !in 0.0..maxAz || el !in 0.0..180.0) {
                                rotatorStatus = "PARK: AZ 0…${maxAz.toInt()}°, EL 0…180°"
                            } else {
                                rotatorTracking = false
                                parkCommandSending = true
                                scope.launch {
                                    try {
                                        val ok = runCatching {
                                            if (rotatorTransport == "TCP") gs232Tcp.setTarget(az, el)
                                            else gs232.setTarget(az, el)
                                        }.getOrDefault(false)

                                        rotatorStatus = if (ok) {
                                            val qr = runCatching {
                                                if (rotatorTransport == "TCP") {
                                                    val r = gs232Tcp.queryAngles()
                                                    r.first?.let {
                                                        Gs232UsbController.Angles(it.azimuthDeg, it.elevationDeg)
                                                    } to r.second
                                                } else {
                                                    gs232.queryAngles()
                                                }
                                            }.getOrNull()

                                            qr?.first?.let {
                                                rotatorActualAz = it.azimuthDeg
                                                rotatorFeedback = "AZ ${"%.0f".format(it.azimuthDeg)}°  EL ${"%.0f".format(it.elevationDeg)}°"
                                            }
                                            "PARK → W%03d %03d отправлена".format(
                                                az.roundToInt(), el.roundToInt()
                                            )
                                        } else {
                                            "Ошибка PARK"
                                        }
                                    } finally {
                                        delay(400)
                                        parkCommandSending = false
                                    }
                                }
                            }
                        },
                        onTrackToggle = {
                            if (!rotatorConnected) rotatorStatus = "Сначала подключите GS-232 контроллер"
                            else { rotatorTracking = !rotatorTracking; rotatorStatus = if (rotatorTracking) "AUTO TRACK запущен" else "AUTO TRACK остановлен" }
                        },
                        onMode360 = {
                            scope.launch {
                                val ok = runCatching { if (rotatorTransport == "TCP") gs232Tcp.set360Mode() else gs232.set360Mode() }.getOrDefault(false)
                                if (ok) {
                                    rotatorMode = "360"
                                    prefs.edit().putString("rotator_mode", "360").apply()
                                    rotatorStatus = "GS-232B: P36 • 360° mode"
                                } else rotatorStatus = "Ошибка P36"
                            }
                        },
                        onMode450 = {
                            scope.launch {
                                val ok = runCatching { if (rotatorTransport == "TCP") gs232Tcp.set450Mode() else gs232.set450Mode() }.getOrDefault(false)
                                if (ok) {
                                    rotatorMode = "450"
                                    prefs.edit().putString("rotator_mode", "450").apply()
                                    rotatorStatus = "GS-232B: P45 • 450° mode"
                                } else rotatorStatus = "Ошибка P45"
                            }
                        },
                    )
                } else Column(Modifier.fillMaxWidth()) {
                    ObserverBlock(
                        observerLat, { observerLat = it; prefs.edit().putString("observer_lat", it).apply() },
                        observerLon, { observerLon = it; prefs.edit().putString("observer_lon", it).apply() },
                        observerAlt, { observerAlt = it; prefs.edit().putString("observer_alt", it).apply() },
                        qthLocator, { qthLocator = it; prefs.edit().putString("qth_locator", it).apply() },
                        onApplyQth = {
                            val ll = maidenheadToLatLon(qthLocator)
                            if (ll != null) {
                                observerLat = "%.6f".format(java.util.Locale.US, ll.first)
                                observerLon = "%.6f".format(java.util.Locale.US, ll.second)
                                qthLocator = latLonToMaidenhead(ll.first, ll.second, 6)
                                prefs.edit().putString("observer_lat", observerLat).putString("observer_lon", observerLon).putString("observer_alt", observerAlt).putString("qth_locator", qthLocator).apply()
                                status = "QTH $qthLocator применён"
                                // QTH affects observer-dependent values only.
                                // The globe orbit track belongs to the selected satellite,
                                // so keep it instead of clearing it here.
                                live = null
                            } else {
                                status = "Неверный QTH Locator"
                            }
                        },
                        onFromCoordinates = {
                            val la = observerLat.toDoubleOrNull(); val lo = observerLon.toDoubleOrNull()
                            if (la != null && lo != null && la in -90.0..90.0 && lo in -180.0..180.0) {
                                qthLocator = latLonToMaidenhead(la, lo, 6)
                                prefs.edit().putString("observer_lat", observerLat).putString("observer_lon", observerLon).putString("observer_alt", observerAlt).putString("qth_locator", qthLocator).apply()
                                status = "QTH: $qthLocator"
                            } else status = "Неверные Latitude / Longitude"
                        },
                        radioMHz, { radioMHz = it }, live, rec,
                        onLocate = {
                            val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            if (fine || coarse) locateNow() else locationPermission.launch(
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            )
                        }
                    )
                    Spacer(Modifier.height(8.dp))
                    SkyRadarCanvas(live, radarPreview)
                    Spacer(Modifier.height(8.dp))
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showMapStyleMenu = true },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
                        ) {
                            ControlButtonText(
                                "MAP: $mapStyle",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        DropdownMenu(
                            expanded = showMapStyleMenu,
                            onDismissRequest = { showMapStyleMenu = false }
                        ) {
                            MAP_STYLES.forEach { style ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            style,
                                            fontWeight = if (style == mapStyle) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        mapStyle = style
                                        prefs.edit().putString("map_style", style).apply()
                                        showMapStyleMenu = false
                                    }
                                )
                            }
                        }
                    }
                    if (mapTextureStatus.isNotBlank()) {
                        Text(
                            mapTextureStatus,
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (mapOrbitMode == "SINGLE") {
                            Button(
                                onClick = {
                                    mapOrbitMode = "SINGLE"
                                    prefs.edit().putString("map_orbit_mode", "SINGLE").apply()
                                },
                                modifier = Modifier.weight(1f).heightIn(min = 46.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                ControlButtonText("ONE SATELLITE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    mapOrbitMode = "SINGLE"
                                    prefs.edit().putString("map_orbit_mode", "SINGLE").apply()
                                },
                                modifier = Modifier.weight(1f).heightIn(min = 46.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                ControlButtonText("ONE SATELLITE", fontSize = 11.sp)
                            }
                        }

                        if (mapOrbitMode == "ALL") {
                            Button(
                                onClick = {
                                    mapOrbitMode = "ALL"
                                    prefs.edit().putString("map_orbit_mode", "ALL").apply()
                                },
                                modifier = Modifier.weight(1f).heightIn(min = 46.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                ControlButtonText("ALL SELECTED", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    mapOrbitMode = "ALL"
                                    prefs.edit().putString("map_orbit_mode", "ALL").apply()
                                },
                                modifier = Modifier.weight(1f).heightIn(min = 46.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                ControlButtonText("ALL SELECTED", fontSize = 11.sp)
                            }
                        }
                    }
                    Text(
                        if (mapOrbitMode == "ALL") {
                            "Орбиты: текущий спутник + выбранные в PASSES"
                        } else {
                            "Орбита: только текущий спутник"
                        },
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                    Spacer(Modifier.height(8.dp))
                    val orbitNoradsForMap = if (mapOrbitMode == "ALL") {
                        buildSet {
                            addAll(passSelectedNorads)
                            add(rec.norad)
                        }
                    } else {
                        setOf(rec.norad)
                    }
                    val mapSatelliteOrbits = records
                        .filter { it.norad in orbitNoradsForMap }
                        .map { sat ->
                            MapSatelliteOrbit(
                                rec = sat,
                                track = multiOrbitTracks[sat.norad].orEmpty(),
                                live = multiOrbitLive[sat.norad]
                            )
                        }

                    OrbitGlobeCanvas(
                        r = rec,
                        live = live,
                        track = track,
                        observerLat = observerLat.toDoubleOrNull(),
                        observerLon = observerLon.toDoubleOrNull(),
                        mapTexture = mapTexture,
                        globeViewMode = globeViewMode,
                        mapSatelliteOrbits = mapSatelliteOrbits,
                        onGlobeViewModeChange = { mode ->
                            globeViewMode = mode
                            prefs.edit().putString("globe_view_mode", mode).apply()
                        }
                    )
                    Spacer(Modifier.height(8.dp))
                    GroundTrackCanvas(
                        points = track,
                        live = live,
                        observerLat = observerLat.toDoubleOrNull(),
                        observerLon = observerLon.toDoubleOrNull(),
                        mapTexture = mapTexture,
                        activeNorad = rec.norad,
                        mapSatelliteOrbits = mapSatelliteOrbits
                    )
                    Spacer(Modifier.height(8.dp))
                    OrbitSummary(rec)
                    Spacer(Modifier.height(8.dp))
                    live?.let { LiveBlock(it, radioMHz) }
                    Spacer(Modifier.height(16.dp))
                }
            } ?: Box(Modifier.fillMaxWidth().heightIn(min = 280.dp), contentAlignment = Alignment.Center) {
                Text("Загрузите TLE-файл.\nПоддерживаются стандартные 2-line и 3-line TLE наборы.", color = Color.LightGray)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "© UA1CFM • Kepler Orbit v0.1.89",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                fontSize = 10.sp,
                color = Color(0xFF73869A)
            )
            Spacer(Modifier.height(4.dp))
        }
    }

    if (showPicker) {
        val pickerFocusManager = LocalFocusManager.current
        AlertDialog(
            onDismissRequest = { pickerFocusManager.clearFocus(force = true); showPicker = false },
            confirmButton = { TextButton(onClick = { pickerFocusManager.clearFocus(force = true); showPicker = false }) { ControlButtonText("CLOSE") } },
            title = { Text("Выбор спутника (${records.size})") },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Поиск: имя или NORAD") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { pickerFocusManager.clearFocus(force = true) }),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    val q = query.trim().lowercase()
                    val filtered = records.filter { q.isBlank() || it.name.lowercase().contains(q) || it.norad.toString().contains(q) }
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        filtered.forEach { r ->
                            Column(Modifier.fillMaxWidth().clickable { pickerFocusManager.clearFocus(force = true); selected = r; prefs.edit().putInt("selected_norad", r.norad).apply(); live = null; passes = emptyList(); showPicker = false }.padding(vertical = 7.dp)) {
                                Text(r.name, fontWeight = FontWeight.Bold, maxLines = 2)
                                Text("NORAD ${r.norad} • ${"%.5f".format(r.meanMotionRevDay)} rev/day • i=${"%.2f".format(r.inclinationDeg)}°", fontSize = 11.sp, color = Color.Gray)
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        )
    }
}


@Composable
private fun RotatorScreen(
    rec: TleRecord,
    live: LivePosition?,
    passCountdown: String,
    connected: Boolean,
    connectionUiState: String,
    stopActive: Boolean,
    tracking: Boolean,
    status: String,
    feedback: String,
    manualAz: String,
    manualEl: String,
    periodMs: String,
    minElevation: String,
    stepDeg: String,
    mode: String,
    parkAz: String,
    parkEl: String,
    parkAfterLos: Boolean,
    manualSending: Boolean,
    parkSending: Boolean,
    transport: String,
    tcpHost: String,
    tcpPort: String,
    onTransportChange: (String) -> Unit,
    onTcpHostChange: (String) -> Unit,
    onTcpPortChange: (String) -> Unit,
    onManualAzChange: (String) -> Unit,
    onManualElChange: (String) -> Unit,
    onPeriodChange: (String) -> Unit,
    onMinElevationChange: (String) -> Unit,
    onStepDegChange: (String) -> Unit,
    onParkAzChange: (String) -> Unit,
    onParkElChange: (String) -> Unit,
    onParkAfterLosChange: (Boolean) -> Unit,
    onRawUsbTest: () -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onQuery: () -> Unit,
    onStop: () -> Unit,
    onManualGo: () -> Unit,
    onPark: () -> Unit,
    onTrackToggle: () -> Unit,
    onMode360: () -> Unit,
    onMode450: () -> Unit,
) {
    val focusManager = LocalFocusManager.current
    fun clearInputFocus() { focusManager.clearFocus(force = true) }

    CardBox("YAESU G-5500 • GS-232B") {
        Text(rec.name, fontWeight = FontWeight.Bold, color = Accent)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (transport == "USB") Button(onClick = { clearInputFocus(); onTransportChange("USB") }, modifier = Modifier.weight(1f)) { ControlButtonText("USB/OTG", fontSize = 12.sp) }
            else OutlinedButton(onClick = { clearInputFocus(); onTransportChange("USB") }, modifier = Modifier.weight(1f)) { ControlButtonText("USB/OTG", fontSize = 12.sp) }
            if (transport == "TCP") Button(onClick = { clearInputFocus(); onTransportChange("TCP") }, modifier = Modifier.weight(1f)) { ControlButtonText("Wi-Fi / TCP", fontSize = 12.sp) }
            else OutlinedButton(onClick = { clearInputFocus(); onTransportChange("TCP") }, modifier = Modifier.weight(1f)) { ControlButtonText("Wi-Fi / TCP", fontSize = 12.sp) }
        }
        if (transport == "TCP") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    tcpHost, onTcpHostChange, label = { Text("Controller IP") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { clearInputFocus() }),
                    modifier = Modifier.weight(1.65f)
                )
                OutlinedTextField(
                    tcpPort, onTcpPortChange, label = { Text("Port") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { clearInputFocus() }),
                    modifier = Modifier.weight(0.75f)
                )
            }
        }
        Text(if (connected) "● ${transport} CONNECTED" else "○ ${transport} DISCONNECTED", color = if (connected) Good else Warn, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(status, color = Color.LightGray, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        Text("ROTATOR FEEDBACK: $feedback", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
        live?.let {
            Text("SGP4 TARGET: AZ ${"%.1f".format(it.azimuthDeg)}°  EL ${"%.1f".format(it.elevationDeg)}°", color = Accent)
            Text(
                passCountdown,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Good
            )
            Text("Range ${"%.0f".format(it.rangeKm)} km • ${if (it.elevationDeg >= 0.0) "ABOVE HORIZON" else "BELOW HORIZON"}", fontSize = 11.sp, color = if (it.elevationDeg >= 0.0) Good else Warn)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (connectionUiState == "CONNECTED") Button(
                onClick = { clearInputFocus(); onConnect() },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) { ControlButtonText("CONNECT", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            else OutlinedButton(
                onClick = { clearInputFocus(); onConnect() },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) { ControlButtonText("CONNECT", fontSize = 12.sp) }

            if (connectionUiState == "DISCONNECTED") Button(
                onClick = { clearInputFocus(); onDisconnect() },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) { ControlButtonText("DISCONNECT", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            else OutlinedButton(
                onClick = { clearInputFocus(); onDisconnect() },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) { ControlButtonText("DISCONNECT", fontSize = 11.sp) }

            OutlinedButton(onClick = { clearInputFocus(); onQuery() }, modifier = Modifier.weight(1f), enabled = connected, contentPadding = PaddingValues(horizontal = 4.dp)) { ControlButtonText("READ C2", fontSize = 11.sp) }
        }
        if (transport == "USB") {
            OutlinedButton(onClick = { clearInputFocus(); onRawUsbTest() }, modifier = Modifier.fillMaxWidth()) {
                ControlButtonText("USB RAW TEST", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (mode == "360") Button(onClick = { clearInputFocus(); onMode360() }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), enabled = connected) { ControlButtonText("P36 • 360°", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            else OutlinedButton(onClick = { clearInputFocus(); onMode360() }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), enabled = connected) { ControlButtonText("P36 • 360°", fontSize = 11.sp) }
            if (mode == "450") Button(onClick = { clearInputFocus(); onMode450() }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), enabled = connected) { ControlButtonText("P45 • 450°", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            else OutlinedButton(onClick = { clearInputFocus(); onMode450() }, modifier = Modifier.weight(1f).heightIn(min = 50.dp), enabled = connected) { ControlButtonText("P45 • 450°", fontSize = 11.sp) }
            if (stopActive) {
                Button(
                    onClick = { clearInputFocus(); onStop() },
                    modifier = Modifier.weight(1f),
                    enabled = connected
                ) { ControlButtonText("STOP S", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            } else {
                OutlinedButton(
                    onClick = { clearInputFocus(); onStop() },
                    modifier = Modifier.weight(1f),
                    enabled = connected
                ) { ControlButtonText("STOP S", fontSize = 10.sp) }
            }
        }
        Text("ACTIVE MODE: ${mode}°", fontSize = 10.sp, color = Accent, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(8.dp))
    CardBox("АВТОМАТИЧЕСКОЕ СЛЕЖЕНИЕ") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                periodMs, onPeriodChange, label = { Text("Calc, ms", fontSize = 10.sp) }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { clearInputFocus() }),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                minElevation, onMinElevationChange, label = { Text("Min EL, °", fontSize = 10.sp) }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { clearInputFocus() }),
                modifier = Modifier.weight(1f)
            )
        }
        Text("ROTATOR STEP: ${stepDeg.toDoubleOrNull()?.roundToInt() ?: 3}°", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Accent)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("1", "3", "5", "7", "10").forEach { v ->
                val selectedStep = stepDeg.toDoubleOrNull()?.roundToInt() == v.toInt()
                if (selectedStep) Button(onClick = { clearInputFocus(); onStepDegChange(v) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp), contentPadding = PaddingValues(horizontal = 1.dp)) {
                    ControlButtonText("$v°", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else OutlinedButton(onClick = { clearInputFocus(); onStepDegChange(v) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp), contentPadding = PaddingValues(horizontal = 1.dp)) {
                    ControlButtonText("$v°", fontSize = 11.sp)
                }
            }
        }
        if (tracking) {
            Button(
                onClick = { clearInputFocus(); onTrackToggle() },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                enabled = connected,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                ControlButtonText("STOP AUTO TRACK", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            OutlinedButton(
                onClick = { clearInputFocus(); onTrackToggle() },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                enabled = connected
            ) {
                ControlButtonText("START AUTO TRACK", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("Независимый шаг AZ/EL • 1° / 3° / 5° / 7° / 10° • ниже Min EL отправляется STOP.", fontSize = 10.sp, color = Color.Gray)
    }
    Spacer(Modifier.height(8.dp))
    CardBox("ПАРКОВКА РОТАТОРА") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                parkAz, onParkAzChange,
                label = { Text("PARK AZ 0…${if (mode == "450") 450 else 360}°", fontSize = 10.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { clearInputFocus() }),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                parkEl, onParkElChange,
                label = { Text("PARK EL 0…180°", fontSize = 10.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { clearInputFocus() }),
                modifier = Modifier.weight(1f)
            )
        }
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Switch(
                checked = parkAfterLos,
                onCheckedChange = onParkAfterLosChange
            )
            Text(
                "PARK AFTER LOS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (parkAfterLos) Good else Color.LightGray
            )
        }
        if (parkSending) {
            Button(
                onClick = { clearInputFocus(); onPark() },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                enabled = connected,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                ControlButtonText("PARK ROTATOR", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            OutlinedButton(
                onClick = { clearInputFocus(); onPark() },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                enabled = connected
            ) {
                ControlButtonText("PARK ROTATOR", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(
            "PARK отправляет W AZ EL. PARK AFTER LOS срабатывает один раз после ухода выбранного спутника ниже 0° и останавливает AUTO TRACK.",
            fontSize = 10.sp,
            color = Color.Gray
        )
    }
    Spacer(Modifier.height(8.dp))
    CardBox("РУЧНАЯ ПРОВЕРКА") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                manualAz, onManualAzChange, label = { Text("AZ 0…${if (mode == "450") 450 else 360}°") }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { clearInputFocus() }),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                manualEl, onManualElChange, label = { Text("EL 0…180°") }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { clearInputFocus() }),
                modifier = Modifier.weight(1f)
            )
        }
        if (manualSending) {
            Button(
                onClick = { clearInputFocus(); onManualGo() },
                modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
                enabled = connected,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                ControlButtonText("SEND Waaa eee", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            OutlinedButton(
                onClick = { clearInputFocus(); onManualGo() },
                modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
                enabled = connected
            ) {
                ControlButtonText("SEND Waaa eee", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun formatCountdown(msRaw: Long): String {
    val total = (msRaw.coerceAtLeast(0L) / 1000L)
    val days = total / 86400L
    val hours = (total % 86400L) / 3600L
    val minutes = (total % 3600L) / 60L
    val seconds = total % 60L
    return if (days > 0L) {
        "%dd %02d:%02d:%02d".format(days, hours, minutes, seconds)
    } else {
        "%02d:%02d:%02d".format(hours, minutes, seconds)
    }
}

@Composable
private fun PassScheduleScreen(
    records: List<TleRecord>,
    selectedNorads: Set<Int>,
    onSelectedNoradsChange: (Set<Int>) -> Unit,
    observerLat: String,
    observerLon: String,
    observerAlt: String,
    minElevation: String,
    onMinElevationChange: (String) -> Unit,
    hours: String,
    onHoursChange: (String) -> Unit,
    passes: List<ScheduledPass>,
    mainScrollState: androidx.compose.foundation.ScrollState,
    rotatorFeedback: String,
    trackingNorad: Int?,
    onSelectTrackingSatellite: (TleRecord) -> Unit,
    onCalculate: () -> Unit,
) {
    val fmtDate = remember { DateTimeFormatter.ofPattern("dd.MM.yyyy") }
    val fmtTime = remember { DateTimeFormatter.ofPattern("HH:mm:ss") }
    val zone = ZoneId.systemDefault()
    var selectedPass by remember { mutableStateOf<ScheduledPass?>(null) }
    var showPassSatellitePicker by remember { mutableStateOf(false) }
    var passSatelliteQuery by remember { mutableStateOf("") }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val passScope = rememberCoroutineScope()
    val passFocusManager = LocalFocusManager.current
    var selectedRadarScrollY by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(1000)
        }
    }

    CardBox("РАСПИСАНИЕ ПРОЛЁТОВ") {
        val selectedNames = records.filter { it.norad in selectedNorads }
        Text(
            if (selectedNames.isEmpty()) "Спутники не выбраны" else "Выбрано спутников: ${selectedNames.size}",
            fontWeight = FontWeight.Bold,
            color = if (selectedNames.isEmpty()) Warn else Accent
        )
        OutlinedButton(
            onClick = { passFocusManager.clearFocus(force = true); showPassSatellitePicker = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                if (selectedNames.size == 1) "SATELLITE: ${selectedNames.first().name}"
                else "SELECT SATELLITES (${selectedNames.size})",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text("$observerLat°, $observerLon° • alt $observerAlt m • LOCAL TIME", fontSize = 11.sp, color = Color.LightGray)
        Text("Min elevation задаёт реальные AOS/LOS", fontSize = 10.sp, color = Color.Gray)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = minElevation,
                onValueChange = onMinElevationChange,
                label = { Text("Min EL, °", fontSize = 11.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { passFocusManager.clearFocus(force = true) }),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = hours,
                onValueChange = { onHoursChange(it.filter { ch -> ch.isDigit() }.take(3)) },
                label = { Text("Hours", fontSize = 11.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { passFocusManager.clearFocus(force = true) }),
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = { passFocusManager.clearFocus(force = true); onCalculate() },
            modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
        ) {
            ControlButtonText("CALCULATE PASSES", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }

    selectedPass?.let { scheduled ->
        Spacer(Modifier.height(8.dp))
        SelectedPassRadar(
            modifier = Modifier.onGloballyPositioned { coordinates ->
                selectedRadarScrollY = coordinates.positionInParent().y.roundToInt()
            },
            rec = scheduled.rec,
            pass = scheduled.pass,
            observerLat = observerLat.toDoubleOrNull(),
            observerLon = observerLon.toDoubleOrNull(),
            observerAltM = observerAlt.toDoubleOrNull() ?: 0.0,
            nowMs = nowMs,
            rotatorFeedback = rotatorFeedback,
            onClose = { selectedPass = null }
        )
    }

    Spacer(Modifier.height(8.dp))
    if (passes.isEmpty()) {
        CardBox("ПРОЛЁТЫ") { Text("Нажмите CALCULATE PASSES.", color = Color.LightGray) }
    } else {
        passes.forEachIndexed { index, scheduled ->
            val pass = scheduled.pass
            val passRec = scheduled.rec
            val aos = pass.aos.toInstant().atZone(zone)
            val mx = pass.maxTime.toInstant().atZone(zone)
            val los = pass.los.toInstant().atZone(zone)
            val mins = pass.durationSeconds / 60
            val secs = pass.durationSeconds % 60
            val active = nowMs in pass.aos.time..pass.los.time
            val progress = if (active) {
                ((nowMs - pass.aos.time).toDouble() / (pass.los.time - pass.aos.time).coerceAtLeast(1L)).coerceIn(0.0, 1.0).toFloat()
            } else 0f
            val timingText = when {
                nowMs < pass.aos.time -> "ДО AOS  ${formatCountdown(pass.aos.time - nowMs)}"
                active -> "ДО LOS  ${formatCountdown(pass.los.time - nowMs)}"
                else -> "ЗАВЕРШЁН"
            }

            CardBox("", modifier = Modifier.clickable {
                onSelectTrackingSatellite(passRec)
                selectedPass = scheduled
                passScope.launch {
                    delay(140)
                    val targetY = (selectedRadarScrollY - 12).coerceAtLeast(0)
                    mainScrollState.animateScrollTo(targetY)
                }
            }) {
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val density = LocalDensity.current
                    val compact = maxWidth < 390.dp || density.fontScale > 1.05f
                    val dateText = if (compact) DateTimeFormatter.ofPattern("dd.MM").format(aos) else fmtDate.format(aos)
                    val line1 = "${index + 1}  ${passRec.name}  •  $dateText  AOS ${fmtTime.format(aos).substring(0,5)}  MAX ${fmtTime.format(mx).substring(0,5)}  LOS ${fmtTime.format(los).substring(0,5)}"
                    Text(line1, fontSize = if (compact) 11.sp else 12.5.sp, fontWeight = FontWeight.SemiBold, color = if (active) Good else Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                if (trackingNorad == passRec.norad) {
                    Text("TRACK TARGET", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent)
                }
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val density = LocalDensity.current
                    val compact = maxWidth < 390.dp || density.fontScale > 1.05f
                    val line2 = if (compact) {
                        "Az ${"%.0f".format(pass.aosAzDeg)}°→${"%.0f".format(pass.maxAzDeg)}°→${"%.0f".format(pass.losAzDeg)}° • El ${"%.1f".format(pass.maxElevationDeg)}° • Δt %02d:%02d".format(mins, secs)
                    } else {
                        "Az AOS/MAX/LOS ${"%.0f".format(pass.aosAzDeg)}°/${"%.0f".format(pass.maxAzDeg)}°/${"%.0f".format(pass.losAzDeg)}° • El max ${"%.1f".format(pass.maxElevationDeg)}° • Δt %02d:%02d".format(mins, secs)
                    }
                    Text(line2, fontSize = if (compact) 10.5.sp else 11.5.sp, color = Color.LightGray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.height(3.dp))
                Text(
                    timingText,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (active) Good else if (nowMs < pass.aos.time) Accent else Color.Gray
                )
                if (active) {
                    Spacer(Modifier.height(5.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ПРОЛЁТ", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Good)
                        Text("${(progress * 100f).roundToInt()}%", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Good)
                    }
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(7.dp),
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }

    if (showPassSatellitePicker) {
        AlertDialog(
            onDismissRequest = { showPassSatellitePicker = false },
            confirmButton = {
                TextButton(onClick = { showPassSatellitePicker = false }) { ControlButtonText("DONE") }
            },
            dismissButton = {
                TextButton(onClick = { onSelectedNoradsChange(emptySet()) }) { ControlButtonText("CLEAR") }
            },
            title = { Text("Спутники для расписания (${selectedNorads.size})") },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                    OutlinedTextField(
                        value = passSatelliteQuery,
                        onValueChange = { passSatelliteQuery = it },
                        label = { Text("Поиск: имя или NORAD") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { passFocusManager.clearFocus(force = true) }),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    val q = passSatelliteQuery.trim().lowercase()
                    val filtered = records.filter {
                        q.isBlank() || it.name.lowercase().contains(q) || it.norad.toString().contains(q)
                    }
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        filtered.forEach { sat ->
                            val checked = sat.norad in selectedNorads
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    onSelectedNoradsChange(
                                        if (checked) selectedNorads - sat.norad else selectedNorads + sat.norad
                                    )
                                }.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = {
                                        onSelectedNoradsChange(
                                            if (checked) selectedNorads - sat.norad else selectedNorads + sat.norad
                                        )
                                    }
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(sat.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("NORAD ${sat.norad}", fontSize = 10.5.sp, color = Color.Gray)
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        )
    }

}

@Composable
private fun SelectedPassRadar(
    modifier: Modifier = Modifier,
    rec: TleRecord,
    pass: SatellitePass,
    observerLat: Double?,
    observerLon: Double?,
    observerAltM: Double,
    nowMs: Long,
    rotatorFeedback: String,
    onClose: () -> Unit,
) {
    val zone = ZoneId.systemDefault()
    val fmt = remember { DateTimeFormatter.ofPattern("dd.MM HH:mm:ss") }
    val points = remember(rec.norad, pass.aos.time, observerLat, observerLon, observerAltM) {
        if (observerLat == null || observerLon == null) emptyList() else radarPointsForPass(rec, pass, observerLat, observerLon, observerAltM)
    }
    val active = nowMs in pass.aos.time..pass.los.time
    val selectedTarget = if (observerLat != null && observerLon != null) {
        runCatching { Sgp4Engine.position(rec, Date(nowMs), observerLat, observerLon, observerAltM) }.getOrNull()
    } else null
    val current = if (active) selectedTarget else null
    val progress = if (active) {
        ((nowMs - pass.aos.time).toDouble() / (pass.los.time - pass.aos.time).coerceAtLeast(1L)).coerceIn(0.0, 1.0).toFloat()
    } else null

    CardBox("РАДАР ВЫБРАННОГО ПРОЛЁТА", modifier = modifier) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(rec.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton(onClick = onClose) { ControlButtonText("CLOSE") }
        }
        Text("AOS ${pass.aos.toInstant().atZone(zone).format(fmt)} • MAX ${"%.1f".format(pass.maxElevationDeg)}° • LOS ${pass.los.toInstant().atZone(zone).format(fmt)}", fontSize = 10.sp, color = Color.LightGray)
        Text(
            when {
                nowMs < pass.aos.time -> "ДО AOS  ${formatCountdown(pass.aos.time - nowMs)}"
                active -> "ДО LOS  ${formatCountdown(pass.los.time - nowMs)}"
                else -> "ПРОЛЁТ ЗАВЕРШЁН"
            },
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (active) Good else if (nowMs < pass.aos.time) Accent else Color.Gray
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "ROTATOR FEEDBACK: $rotatorFeedback",
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 13.sp
        )
        Text(
            if (selectedTarget != null)
                "SGP4 TARGET: AZ ${"%.1f".format(selectedTarget.azimuthDeg)}°  EL ${"%.1f".format(selectedTarget.elevationDeg)}°"
            else
                "SGP4 TARGET: AZ ---°  EL ---°",
            fontWeight = FontWeight.Bold,
            color = Accent,
            fontSize = 13.sp
        )
        Spacer(Modifier.height(6.dp))
        SkyPassRadarCanvas(points, current)
        if (progress != null) {
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("СЕЙЧАС ИДЁТ ПРОЛЁТ", color = Good, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("${(progress * 100f).roundToInt()}%", color = Good, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp))
        }
    }
}

@Composable
private fun SkyPassRadarCanvas(points: List<SkyPoint>, current: LivePosition?) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(1f).heightIn(max = 370.dp).background(Color(0xFF050D18), RoundedCornerShape(10.dp))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = minOf(size.width, size.height) * 0.44f
            fun pt(az: Double, el: Double): Offset {
                val rr = radius * ((90.0 - el.coerceIn(0.0, 90.0)) / 90.0).toFloat()
                val a = Math.toRadians(az - 90.0)
                return Offset(cx + rr * kotlin.math.cos(a).toFloat(), cy + rr * kotlin.math.sin(a).toFloat())
            }
            listOf(1f, 2f/3f, 1f/3f).forEachIndexed { i, k ->
                drawCircle(if (i == 0) Accent.copy(alpha = .55f) else Color(0xFF35506E), radius * k, Offset(cx, cy), style = Stroke(if (i == 0) 3f else 1.5f))
            }
            drawLine(Color(0xFF35506E), Offset(cx-radius,cy), Offset(cx+radius,cy), 1.5f)
            drawLine(Color(0xFF35506E), Offset(cx,cy-radius), Offset(cx,cy+radius), 1.5f)
            var prev: Offset? = null
            points.forEach { sp ->
                val cur = pt(sp.azimuthDeg, sp.elevationDeg)
                prev?.let { drawLine(Accent, it, cur, 3.2f) }
                prev = cur
            }
            points.firstOrNull()?.let { drawCircle(Good, 6f, pt(it.azimuthDeg, it.elevationDeg)) }
            points.lastOrNull()?.let { drawCircle(Warn, 6f, pt(it.azimuthDeg, it.elevationDeg)) }
            current?.takeIf { it.elevationDeg >= 0.0 }?.let {
                val cur = pt(it.azimuthDeg, it.elevationDeg)
                drawCircle(Color(0xFFFF5252), 9f, cur)
                drawCircle(Color.White, 13f, cur, style = Stroke(2f))
            }
        }
        Text("N", color=Color.LightGray, modifier=Modifier.align(Alignment.TopCenter).padding(top=8.dp), fontSize=11.sp)
        Text("S", color=Color.LightGray, modifier=Modifier.align(Alignment.BottomCenter).padding(bottom=8.dp), fontSize=11.sp)
        Text("E", color=Color.LightGray, modifier=Modifier.align(Alignment.CenterEnd).padding(end=10.dp), fontSize=11.sp)
        Text("W", color=Color.LightGray, modifier=Modifier.align(Alignment.CenterStart).padding(start=10.dp), fontSize=11.sp)
        Text("90°", color=Color(0xFF7E93A7), modifier=Modifier.align(Alignment.Center), fontSize=10.sp)
    }
}

private fun radarPointsForPass(
    rec: TleRecord,
    pass: SatellitePass,
    observerLat: Double,
    observerLon: Double,
    observerAltM: Double,
): List<SkyPoint> {
    val durationMs = (pass.los.time - pass.aos.time).coerceAtLeast(60_000L)
    val stepMs = (durationMs / 100L).coerceIn(1_500L, 12_000L)
    val out = mutableListOf<SkyPoint>()
    var t = pass.aos.time
    while (t <= pass.los.time) {
        val p = Sgp4Engine.position(rec, Date(t), observerLat, observerLon, observerAltM)
        if (p.elevationDeg >= 0.0) out += SkyPoint(p.azimuthDeg, p.elevationDeg)
        t += stepMs
    }
    if (out.isNotEmpty() && t - stepMs < pass.los.time) {
        val p = Sgp4Engine.position(rec, pass.los, observerLat, observerLon, observerAltM)
        if (p.elevationDeg >= -0.2) out += SkyPoint(p.azimuthDeg, p.elevationDeg.coerceAtLeast(0.0))
    }
    return out
}

@Composable private fun OrbitSummary(r: TleRecord) {
    CardBox("ОРБИТА") {
        Param("Тип", r.orbitalClass, "")
        Param("Период", "${"%.2f".format(r.periodMinutes)} min", "")
        Param("Перигей / Апогей", "${"%.0f".format(r.perigeeAltKm)} / ${"%.0f".format(r.apogeeAltKm)} km", "")
        Param("Наклонение", "${"%.2f".format(r.inclinationDeg)}°", "")
        val age = Duration.between(r.epochInstant, java.time.Instant.now()).toHours() / 24.0
        Param("Возраст TLE", "${"%.2f".format(age)} days", "")
    }
}

@Composable private fun SkyRadarCanvas(live: LivePosition?, preview: RadarPreview?) {
    CardBox("РАДАР ПРОЛЁТА") {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .heightIn(max = 330.dp)
                .background(Color(0xFF050D18), RoundedCornerShape(10.dp))
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val radius = minOf(size.width, size.height) * 0.44f

                fun skyPoint(az: Double, el: Double): Offset {
                    val rr = radius * ((90.0 - el.coerceIn(0.0, 90.0)) / 90.0).toFloat()
                    val ang = Math.toRadians(az - 90.0)
                    return Offset(
                        cx + (rr * kotlin.math.cos(ang).toFloat()),
                        cy + (rr * kotlin.math.sin(ang).toFloat())
                    )
                }

                listOf(1.0f, 2f / 3f, 1f / 3f).forEachIndexed { idx, k ->
                    drawCircle(
                        color = if (idx == 0) Accent.copy(alpha = 0.55f) else Color(0xFF35506E),
                        radius = radius * k,
                        center = Offset(cx, cy),
                        style = Stroke(if (idx == 0) 3f else 1.5f)
                    )
                }
                drawLine(Color(0xFF35506E), Offset(cx - radius, cy), Offset(cx + radius, cy), 1.5f)
                drawLine(Color(0xFF35506E), Offset(cx, cy - radius), Offset(cx, cy + radius), 1.5f)
                drawCircle(Color.White.copy(alpha = 0.9f), 3f, Offset(cx, cy))

                val pts = preview?.points.orEmpty()
                var prev: Offset? = null
                for (sp in pts) {
                    val cur = skyPoint(sp.azimuthDeg, sp.elevationDeg)
                    prev?.let { drawLine(Accent, it, cur, 3f) }
                    prev = cur
                }
                pts.firstOrNull()?.let { drawCircle(Good, 6f, skyPoint(it.azimuthDeg, it.elevationDeg)) }
                pts.lastOrNull()?.let { drawCircle(Warn, 6f, skyPoint(it.azimuthDeg, it.elevationDeg)) }

                live?.takeIf { it.elevationDeg >= 0.0 }?.let {
                    val cur = skyPoint(it.azimuthDeg, it.elevationDeg)
                    drawCircle(Color(0xFFFF5252), 9f, cur)
                    drawCircle(Color.White, 13f, cur, style = Stroke(2f))
                }
            }

            Text("N", color = Color.LightGray, modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp), fontSize = 11.sp)
            Text("S", color = Color.LightGray, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp), fontSize = 11.sp)
            Text("E", color = Color.LightGray, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 10.dp), fontSize = 11.sp)
            Text("W", color = Color.LightGray, modifier = Modifier.align(Alignment.CenterStart).padding(start = 10.dp), fontSize = 11.sp)
            Text("90°", color = Color(0xFF7E93A7), modifier = Modifier.align(Alignment.Center), fontSize = 10.sp)
        }

        Spacer(Modifier.height(6.dp))
        Text(preview?.label ?: "Нет данных по пролёту", fontSize = 11.sp, color = Color.LightGray)
        live?.let {
            Text(
                "AZ ${"%.1f".format(it.azimuthDeg)}° • EL ${"%.1f".format(it.elevationDeg)}° • Range ${"%.0f".format(it.rangeKm)} km",
                fontSize = 11.sp,
                color = if (it.elevationDeg >= 0.0) Good else Color.LightGray,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private fun computeRadarPreview(
    rec: TleRecord,
    observerLat: Double,
    observerLon: Double,
    observerAltM: Double,
    now: Date = Date(),
): RadarPreview? {
    val searchStart = Date(now.time - 3L * 3600_000L)
    val passes = PassPredictor.nextPasses(rec, observerLat, observerLon, observerAltM, searchStart, 12, 0.0, 8)
    val pass = passes.firstOrNull { now.time in it.aos.time..it.los.time }
        ?: passes.firstOrNull { it.aos.after(now) }
        ?: return null

    val durationMs = (pass.los.time - pass.aos.time).coerceAtLeast(60_000L)
    val stepMs = (durationMs / 90L).coerceIn(2_000L, 15_000L)
    val points = mutableListOf<SkyPoint>()
    var t = pass.aos.time
    while (t <= pass.los.time) {
        val p = Sgp4Engine.position(rec, Date(t), observerLat, observerLon, observerAltM)
        if (p.elevationDeg >= 0.0) points += SkyPoint(p.azimuthDeg, p.elevationDeg)
        t += stepMs
    }
    if (points.isEmpty()) return null

    val fmt = DateTimeFormatter.ofPattern("HH:mm:ss")
    val zone = ZoneId.systemDefault()
    val active = now.time in pass.aos.time..pass.los.time
    val label = if (active) {
        "ON PASS • MAX ${"%.0f".format(pass.maxElevationDeg)}° • LOS ${pass.los.toInstant().atZone(zone).format(fmt)}"
    } else {
        "NEXT PASS • AOS ${pass.aos.toInstant().atZone(zone).format(fmt)} • MAX ${"%.0f".format(pass.maxElevationDeg)}°"
    }
    return RadarPreview(points, label, active)
}

private data class EarthFacingPoint(val latDeg: Double, val lonDeg: Double)

private fun normalizeDegrees180(value: Double): Double {
    var v = value % 360.0
    if (v > 180.0) v -= 360.0
    if (v < -180.0) v += 360.0
    return v
}

private fun normalizeDegrees360(value: Double): Double {
    var v = value % 360.0
    if (v < 0.0) v += 360.0
    return v
}

private fun julianDayUtc(timeMs: Long): Double =
    timeMs / 86_400_000.0 + 2440587.5

private fun greenwichSiderealDeg(jd: Double): Double {
    val t = (jd - 2451545.0) / 36525.0
    return normalizeDegrees360(
        280.46061837 +
            360.98564736629 * (jd - 2451545.0) +
            0.000387933 * t * t -
            t * t * t / 38710000.0
    )
}

private fun subSolarPoint(timeMs: Long): EarthFacingPoint {
    val jd = julianDayUtc(timeMs)
    val n = jd - 2451545.0

    val meanLon = normalizeDegrees360(280.460 + 0.9856474 * n)
    val meanAnomaly = Math.toRadians(normalizeDegrees360(357.528 + 0.9856003 * n))
    val eclipticLon = Math.toRadians(
        normalizeDegrees360(
            meanLon +
                1.915 * kotlin.math.sin(meanAnomaly) +
                0.020 * kotlin.math.sin(2.0 * meanAnomaly)
        )
    )
    val obliquity = Math.toRadians(23.439 - 0.0000004 * n)

    val ra = kotlin.math.atan2(
        kotlin.math.cos(obliquity) * kotlin.math.sin(eclipticLon),
        kotlin.math.cos(eclipticLon)
    )
    val dec = kotlin.math.asin(
        kotlin.math.sin(obliquity) * kotlin.math.sin(eclipticLon)
    )

    val raDeg = normalizeDegrees360(Math.toDegrees(ra))
    val lon = normalizeDegrees180(raDeg - greenwichSiderealDeg(jd))
    return EarthFacingPoint(Math.toDegrees(dec), lon)
}

private fun subLunarPoint(timeMs: Long): EarthFacingPoint {
    // Compact low-precision geocentric Moon model suitable for globe orientation.
    // It includes the dominant lunar perturbations and is far more accurate than
    // simply advancing the Moon at a constant daily rate.
    val jd = julianDayUtc(timeMs)
    val d = jd - 2451543.5

    val nDeg = normalizeDegrees360(125.1228 - 0.0529538083 * d)
    val iDeg = 5.1454
    val wDeg = normalizeDegrees360(318.0634 + 0.1643573223 * d)
    val a = 60.2666
    val e = 0.054900
    val mDeg = normalizeDegrees360(115.3654 + 13.0649929509 * d)

    val m = Math.toRadians(mDeg)
    var eAnom = m + e * kotlin.math.sin(m) * (1.0 + e * kotlin.math.cos(m))
    repeat(3) {
        eAnom -= (eAnom - e * kotlin.math.sin(eAnom) - m) /
            (1.0 - e * kotlin.math.cos(eAnom))
    }

    val xv = a * (kotlin.math.cos(eAnom) - e)
    val yv = a * kotlin.math.sqrt(1.0 - e * e) * kotlin.math.sin(eAnom)
    val v = kotlin.math.atan2(yv, xv)
    val r = kotlin.math.sqrt(xv * xv + yv * yv)

    val nRad = Math.toRadians(nDeg)
    val iRad = Math.toRadians(iDeg)
    val vw = v + Math.toRadians(wDeg)

    var xh = r * (
        kotlin.math.cos(nRad) * kotlin.math.cos(vw) -
            kotlin.math.sin(nRad) * kotlin.math.sin(vw) * kotlin.math.cos(iRad)
        )
    var yh = r * (
        kotlin.math.sin(nRad) * kotlin.math.cos(vw) +
            kotlin.math.cos(nRad) * kotlin.math.sin(vw) * kotlin.math.cos(iRad)
        )
    var zh = r * kotlin.math.sin(vw) * kotlin.math.sin(iRad)

    var lon = kotlin.math.atan2(yh, xh)
    var lat = kotlin.math.atan2(zh, kotlin.math.sqrt(xh * xh + yh * yh))

    // Dominant perturbations from the Sun.
    val wsDeg = normalizeDegrees360(282.9404 + 4.70935E-5 * d)
    val msDeg = normalizeDegrees360(356.0470 + 0.9856002585 * d)
    val lsDeg = normalizeDegrees360(wsDeg + msDeg)
    val lmDeg = normalizeDegrees360(nDeg + wDeg + mDeg)
    val dMoonDeg = normalizeDegrees180(lmDeg - lsDeg)
    val fDeg = normalizeDegrees180(lmDeg - nDeg)

    var lonDeg = Math.toDegrees(lon)
    var latDeg = Math.toDegrees(lat)

    lonDeg +=
        -1.274 * kotlin.math.sin(Math.toRadians(mDeg - 2.0 * dMoonDeg)) +
        0.658 * kotlin.math.sin(Math.toRadians(2.0 * dMoonDeg)) -
        0.186 * kotlin.math.sin(Math.toRadians(msDeg)) -
        0.059 * kotlin.math.sin(Math.toRadians(2.0 * mDeg - 2.0 * dMoonDeg)) -
        0.057 * kotlin.math.sin(Math.toRadians(mDeg - 2.0 * dMoonDeg + msDeg)) +
        0.053 * kotlin.math.sin(Math.toRadians(mDeg + 2.0 * dMoonDeg)) +
        0.046 * kotlin.math.sin(Math.toRadians(2.0 * dMoonDeg - msDeg)) +
        0.041 * kotlin.math.sin(Math.toRadians(mDeg - msDeg)) -
        0.035 * kotlin.math.sin(Math.toRadians(dMoonDeg)) -
        0.031 * kotlin.math.sin(Math.toRadians(mDeg + msDeg)) -
        0.015 * kotlin.math.sin(Math.toRadians(2.0 * fDeg - 2.0 * dMoonDeg)) +
        0.011 * kotlin.math.sin(Math.toRadians(mDeg - 4.0 * dMoonDeg))

    latDeg +=
        -0.173 * kotlin.math.sin(Math.toRadians(fDeg - 2.0 * dMoonDeg)) -
        0.055 * kotlin.math.sin(Math.toRadians(mDeg - fDeg - 2.0 * dMoonDeg)) -
        0.046 * kotlin.math.sin(Math.toRadians(mDeg + fDeg - 2.0 * dMoonDeg)) +
        0.033 * kotlin.math.sin(Math.toRadians(fDeg + 2.0 * dMoonDeg)) +
        0.017 * kotlin.math.sin(Math.toRadians(2.0 * mDeg + fDeg))

    lon = Math.toRadians(lonDeg)
    lat = Math.toRadians(latDeg)

    // Ecliptic -> equatorial.
    val obliquity = Math.toRadians(23.4393 - 3.563E-7 * d)
    val xe = kotlin.math.cos(lon) * kotlin.math.cos(lat)
    val ye = kotlin.math.sin(lon) * kotlin.math.cos(lat)
    val ze = kotlin.math.sin(lat)

    val xeq = xe
    val yeq = ye * kotlin.math.cos(obliquity) - ze * kotlin.math.sin(obliquity)
    val zeq = ye * kotlin.math.sin(obliquity) + ze * kotlin.math.cos(obliquity)

    val ra = kotlin.math.atan2(yeq, xeq)
    val dec = kotlin.math.atan2(zeq, kotlin.math.sqrt(xeq * xeq + yeq * yeq))

    val raDeg = normalizeDegrees360(Math.toDegrees(ra))
    val earthLon = normalizeDegrees180(raDeg - greenwichSiderealDeg(jd))
    return EarthFacingPoint(Math.toDegrees(dec), earthLon)
}

@Composable
private fun OrbitGlobeCanvas(
    r: TleRecord,
    live: LivePosition?,
    track: List<GroundPoint>,
    observerLat: Double?,
    observerLon: Double?,
    mapTexture: Bitmap?,
    globeViewMode: String,
    mapSatelliteOrbits: List<MapSatelliteOrbit>,
    onGlobeViewModeChange: (String) -> Unit
) {
    CardBox("3D ГЛОБУС • ТЕКУЩЕЕ ПОЛОЖЕНИЕ • ОРБИТА") {
        val context = LocalContext.current
        var astronomyNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

        LaunchedEffect(globeViewMode) {
            while (true) {
                astronomyNowMs = System.currentTimeMillis()
                delay(if (globeViewMode == "SUN" || globeViewMode == "MOON") 15_000L else 60_000L)
            }
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("TRACK", "QTH", "SUN", "MOON").forEach { mode ->
                if (globeViewMode == mode) {
                    Button(
                        onClick = { onGlobeViewModeChange(mode) },
                        modifier = Modifier.weight(1f).heightIn(min = 46.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        ControlButtonText(mode, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    OutlinedButton(
                        onClick = { onGlobeViewModeChange(mode) },
                        modifier = Modifier.weight(1f).heightIn(min = 46.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        ControlButtonText(mode, fontSize = 10.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))

        val sunPoint = remember(astronomyNowMs / 15_000L) {
            subSolarPoint(astronomyNowMs)
        }
        val moonPoint = remember(astronomyNowMs / 15_000L) {
            subLunarPoint(astronomyNowMs)
        }

        val centerLat = when (globeViewMode) {
            "SUN" -> sunPoint.latDeg
            "MOON" -> moonPoint.latDeg
            "QTH" -> observerLat ?: (live?.latitudeDeg ?: 20.0)
            else -> live?.latitudeDeg ?: 20.0
        }
        val centerLon = when (globeViewMode) {
            "SUN" -> sunPoint.lonDeg
            "MOON" -> moonPoint.lonDeg
            "QTH" -> observerLon ?: (live?.longitudeDeg ?: 20.0)
            else -> live?.longitudeDeg ?: 20.0
        }

        val globeBitmap = remember(
            kotlin.math.round(centerLat * 2.0) / 2.0,
            kotlin.math.round(centerLon * 2.0) / 2.0,
            mapTexture,
            globeViewMode,
            astronomyNowMs / 15_000L
        ) {
            renderOrthographicGlobe(
                context,
                centerLat,
                centerLon,
                420,
                mapTexture,
                if (globeViewMode == "SUN") sunPoint else null
            )
        }

        // UNIFIED AUTO ZOOM FOR TRACK / SUN / MOON.
        // The scale is intentionally independent of camera orientation.
        // It is based only on the true maximum orbital radius R = Re + h,
        // so switching TRACK/SUN/MOON changes only the viewing direction,
        // never the Earth/orbit proportions.
        val earthKmForZoom = 6378.137
        val maxDisplayedAltitudeKm = buildList {
            track.maxOfOrNull { it.altitudeKm }?.let { add(it.coerceAtLeast(0.0)) }
            mapSatelliteOrbits.forEach { orbit ->
                orbit.track.maxOfOrNull { it.altitudeKm }?.let { add(it.coerceAtLeast(0.0)) }
                orbit.live?.altitudeKm?.let { add(it.coerceAtLeast(0.0)) }
            }
            live?.altitudeKm?.let { add(it.coerceAtLeast(0.0)) }
        }.maxOrNull() ?: 0.0

        val maxOrbitRadiusScale =
            ((earthKmForZoom + maxDisplayedAltitudeKm) / earthKmForZoom)
                .coerceAtLeast(1.0)

        // Base Earth radius is 0.455 of the viewport. Keep the full highest orbit
        // inside the viewport with a small edge margin. This same zoom is then
        // applied to BOTH the globe bitmap and every vector overlay.
        val autoZoom = (0.48 / (0.455 * maxOrbitRadiusScale))
            .coerceIn(0.68, 1.0)

        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .heightIn(max = 330.dp)
                .background(Color(0xFF050D18), RoundedCornerShape(10.dp))
        ) {
            Image(
                bitmap = globeBitmap.asImageBitmap(),
                contentDescription = "Rotating textured world globe",
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = autoZoom.toFloat(),
                        scaleY = autoZoom.toFloat()
                    ),
                contentScale = ContentScale.Fit
            )

            Canvas(Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val earthR = minOf(size.width, size.height) * 0.455f * autoZoom.toFloat()
                val lat0 = Math.toRadians(centerLat)
                val lon0 = Math.toRadians(centerLon)
                val earthKm = 6378.137
                val globeCenter = Offset(cx, cy)

                data class P3(val p: Offset, val z: Double)

                fun project(latDeg: Double, lonDeg: Double, radiusScale: Double = 1.0): P3 {
                    val lat = Math.toRadians(latDeg)
                    var dl = Math.toRadians(lonDeg) - lon0
                    while (dl > Math.PI) dl -= 2.0 * Math.PI
                    while (dl < -Math.PI) dl += 2.0 * Math.PI
                    val x = kotlin.math.cos(lat) * kotlin.math.sin(dl)
                    val y = kotlin.math.cos(lat0) * kotlin.math.sin(lat) -
                        kotlin.math.sin(lat0) * kotlin.math.cos(lat) * kotlin.math.cos(dl)
                    val z = kotlin.math.sin(lat0) * kotlin.math.sin(lat) +
                        kotlin.math.cos(lat0) * kotlin.math.cos(lat) * kotlin.math.cos(dl)
                    return P3(
                        Offset(
                            cx + (earthR * radiusScale * x).toFloat(),
                            cy - (earthR * radiusScale * y).toFloat()
                        ), z * radiusScale
                    )
                }

                // SGP4-орбиту рисуем полным кольцом вокруг глобуса.
                // Передняя полудуга — яркая, задняя — более тусклая,
                // чтобы орбита не выглядела обрезанной на краю диска Земли.
                if (track.size > 1) {
                    val orbitPoints = track.map { gp ->
                        val radiusScale = (earthKm + gp.altitudeKm.coerceAtLeast(0.0)) / earthKm
                        project(gp.latDeg, gp.lonDeg, radiusScale)
                    }
                    for (i in 1 until orbitPoints.size) {
                        val a = orbitPoints[i - 1]
                        val b = orbitPoints[i]
                        val segmentLength = (b.p - a.p).getDistance()
                        if (segmentLength <= earthR * 0.65f) {
                            val avgZ = (a.z + b.z) / 2.0
                            val color = if (avgZ >= 0.0) Accent else Accent.copy(alpha = 0.34f)
                            val width = if (avgZ >= 0.0) 3.2f else 2.0f
                            drawLine(color, a.p, b.p, width)
                        }
                    }
                    // Do not connect the end of the sampled current orbit back to the beginning.
                    // A visible gap is intentional here and avoids a false closing chord.
                }

                // Additional satellites selected in PASSES.
                // Draw exactly ONE current orbital revolution for each satellite.
                mapSatelliteOrbits
                    .filter { it.rec.norad != r.norad && it.track.size > 1 }
                    .forEachIndexed { index, orbit ->
                        val baseColor = secondaryOrbitColor(index)
                        val orbitPoints = orbit.track.map { gp ->
                            val radiusScale = (earthKm + gp.altitudeKm.coerceAtLeast(0.0)) / earthKm
                            project(gp.latDeg, gp.lonDeg, radiusScale)
                        }

                        for (i in 1 until orbitPoints.size) {
                            val a = orbitPoints[i - 1]
                            val b = orbitPoints[i]
                            val segmentLength = (b.p - a.p).getDistance()
                            if (segmentLength <= earthR * 0.65f) {
                                val front = (a.z + b.z) / 2.0 >= 0.0
                                drawLine(
                                    if (front) baseColor.copy(alpha = 0.82f) else baseColor.copy(alpha = 0.22f),
                                    a.p,
                                    b.p,
                                    if (front) 2.1f else 1.4f
                                )
                            }
                        }

                        // Keep a small gap between the first and last sampled points
                        // of the revolution instead of drawing an artificial closing line.

                        orbit.live?.let { sat ->
                            val footprint = Sgp4Engine.visibilityFootprint(
                                sat.latitudeDeg,
                                sat.longitudeDeg,
                                sat.altitudeKm
                            )
                            var previousFootprint: P3? = null
                            footprint.forEach { gp ->
                                val cur = project(gp.latDeg, gp.lonDeg)
                                val old = previousFootprint
                                if (old != null && old.z >= 0.0 && cur.z >= 0.0) {
                                    drawLine(
                                        baseColor.copy(alpha = 0.78f),
                                        old.p,
                                        cur.p,
                                        1.8f
                                    )
                                }
                                previousFootprint = cur
                            }

                            val satScale = (earthKm + sat.altitudeKm.coerceAtLeast(0.0)) / earthKm
                            val p = project(sat.latitudeDeg, sat.longitudeDeg, satScale)
                            if (p.z >= 0.0) {
                                drawLine(
                                    baseColor.copy(alpha = 0.45f),
                                    globeCenter,
                                    p.p,
                                    1.5f
                                )
                                drawCircle(baseColor, 5.5f, p.p)
                                drawCircle(Color.White.copy(alpha = 0.75f), 8f, p.p, style = Stroke(1.3f))
                            }
                        }
                    }

                live?.let { sat ->
                    // Зона геометрической радиовидимости лежит на поверхности глобуса.
                    val fp = Sgp4Engine.visibilityFootprint(
                        sat.latitudeDeg, sat.longitudeDeg, sat.altitudeKm
                    )
                    var prev: P3? = null
                    fp.forEach { gp ->
                        val cur = project(gp.latDeg, gp.lonDeg)
                        val old = prev
                        if (old != null && old.z >= 0.0 && cur.z >= 0.0) {
                            drawLine(Warn, old.p, cur.p, 3f)
                        }
                        prev = cur
                    }

                    // Сам спутник рисуем выше поверхности на его реальной высоте.
                    val satScale = (earthKm + sat.altitudeKm.coerceAtLeast(0.0)) / earthKm
                    val satP = project(sat.latitudeDeg, sat.longitudeDeg, satScale)
                    if (satP.z >= 0.0) {
                        // Геоцентрический радиус к текущему спутнику: от центра диска Земли
                        // до точки спутника на его реальной высоте. Это наглядно показывает
                        // масштаб орбиты относительно Земли и работает одинаково в TRACK/SUN/MOON.
                        drawLine(
                            Color.White.copy(alpha = 0.55f),
                            globeCenter,
                            satP.p,
                            2.1f
                        )
                        drawCircle(Color(0xFFFF5252), 8f, satP.p)
                        drawCircle(Color.White, 12f, satP.p, style = Stroke(2f))
                    }

                    // Подспутниковая точка на поверхности — точно под спутником.
                    val sub = project(sat.latitudeDeg, sat.longitudeDeg)
                    if (sub.z >= 0.0) {
                        drawCircle(Color.White.copy(alpha = 0.9f), 4f, sub.p)
                        drawLine(Color.White.copy(alpha = 0.42f), sub.p, satP.p, 1.3f)
                    }
                }

                if (observerLat != null && observerLon != null) {
                    val obs = project(observerLat, observerLon)
                    if (obs.z >= 0.0) {
                        val inside = live?.let {
                            Sgp4Engine.observerInsideFootprint(
                                it.latitudeDeg, it.longitudeDeg, it.altitudeKm,
                                observerLat, observerLon
                            )
                        } ?: false
                        val c = if (inside) Good else Color(0xFFFF8A80)
                        drawCircle(c, 6f, obs.p)
                        drawLine(c, Offset(obs.p.x - 9f, obs.p.y), Offset(obs.p.x + 9f, obs.p.y), 2f)
                        drawLine(c, Offset(obs.p.x, obs.p.y - 9f), Offset(obs.p.x, obs.p.y + 9f), 2f)
                    }
                }

                if (globeViewMode == "SUN") {
                    val p = project(sunPoint.latDeg, sunPoint.lonDeg)
                    if (p.z >= 0.0) {
                        drawCircle(Color(0xFFFFD54F), 8f, p.p)
                        drawCircle(Color.White.copy(alpha = 0.9f), 12f, p.p, style = Stroke(2f))
                    }
                } else if (globeViewMode == "MOON") {
                    val p = project(moonPoint.latDeg, moonPoint.lonDeg)
                    if (p.z >= 0.0) {
                        drawCircle(Color(0xFFE0E0E0), 8f, p.p)
                        drawCircle(Accent.copy(alpha = 0.9f), 12f, p.p, style = Stroke(2f))
                    }
                }

                // Атмосферный обод поверх динамически повернутой текстуры.
                drawCircle(Accent.copy(alpha = 0.45f), earthR, Offset(cx, cy), style = Stroke(3f))
            }
        }

        Spacer(Modifier.height(6.dp))
        if (mapSatelliteOrbits.size > 1) {
            Text(
                "CURRENT ORBITS: ${mapSatelliteOrbits.size} • орбиты + круги радиовидимости" +
                    if (autoZoom < 0.995) " • AUTO ZOOM ${"%.0f".format(autoZoom * 100.0)}%" else "",
                fontSize = 10.sp,
                color = Color.LightGray
            )
            Spacer(Modifier.height(3.dp))
        } else if (autoZoom < 0.995) {
            Text(
                "AUTO ZOOM ${"%.0f".format(autoZoom * 100.0)}% • текущая орбита полностью в окне",
                fontSize = 10.sp,
                color = Color.LightGray
            )
            Spacer(Modifier.height(3.dp))
        }
        Text(
            when (globeViewMode) {
                "SUN" -> "SUN VIEW • центр — подсолнечная точка • затемнение показывает ночную полусферу"
                "MOON" -> "MOON VIEW • центр — подлунная точка"
                "QTH" -> if (observerLat == null || observerLon == null) {
                    "QTH VIEW • координаты наблюдателя не заданы"
                } else {
                    "QTH VIEW • центр — QTH наблюдателя • крест — точка наблюдателя"
                }
                else -> if (live == null) {
                    "TRACK VIEW • орбита вокруг глобуса • красная точка — спутник"
                } else {
                    "TRACK VIEW • красная — спутник • белая — подспутниковая точка"
                }
            },
            fontSize = 11.sp,
            color = Color.LightGray
        )
    }
}

private fun renderOrthographicGlobe(
    context: Context,
    centerLatDeg: Double,
    centerLonDeg: Double,
    sizePx: Int,
    mapTexture: Bitmap?,
    illuminationPoint: EarthFacingPoint? = null
): Bitmap {
    val src = mapTexture
        ?: BitmapFactory.decodeResource(context.resources, R.drawable.world_map)
    val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val bg = android.graphics.Color.rgb(5, 13, 24)
    val lat0 = Math.toRadians(centerLatDeg)
    val lon0 = Math.toRadians(centerLonDeg)
    val cLat0 = kotlin.math.cos(lat0)
    val sLat0 = kotlin.math.sin(lat0)
    val r = sizePx * 0.455
    val cx = sizePx / 2.0
    val cy = sizePx / 2.0

    for (py in 0 until sizePx) {
        for (px in 0 until sizePx) {
            val x = (px - cx) / r
            val y = (cy - py) / r
            val rho2 = x * x + y * y
            if (rho2 > 1.0) {
                out.setPixel(px, py, bg)
                continue
            }
            val rho = kotlin.math.sqrt(rho2)
            val c = kotlin.math.asin(rho.coerceIn(0.0, 1.0))
            val sinC = kotlin.math.sin(c)
            val cosC = kotlin.math.cos(c)
            val lat = if (rho < 1e-9) lat0 else kotlin.math.asin(
                (cosC * sLat0 + y * sinC * cLat0 / rho).coerceIn(-1.0, 1.0)
            )
            var lon = if (rho < 1e-9) lon0 else lon0 + kotlin.math.atan2(
                x * sinC,
                rho * cLat0 * cosC - y * sLat0 * sinC
            )
            while (lon > Math.PI) lon -= 2.0 * Math.PI
            while (lon < -Math.PI) lon += 2.0 * Math.PI

            val u = ((lon + Math.PI) / (2.0 * Math.PI) * (src.width - 1)).toInt().coerceIn(0, src.width - 1)
            val v = ((Math.PI / 2.0 - lat) / Math.PI * (src.height - 1)).toInt().coerceIn(0, src.height - 1)
            val color = src.getPixel(u, v)

            // Лёгкое затенение к краю делает шар объёмнее.
            val limb = kotlin.math.sqrt((1.0 - rho2).coerceAtLeast(0.0))
            var k = 0.58 + 0.42 * limb

            // В SUN VIEW добавляем физически осмысленную дневную/ночную полусферу.
            // Скалярное произведение нормали поверхности и направления на Солнце
            // равно cos солнечного зенитного угла; граница 0 — терминатор.
            illuminationPoint?.let { sun ->
                val sunLat = Math.toRadians(sun.latDeg)
                val sunLon = Math.toRadians(sun.lonDeg)
                val cosZenith =
                    kotlin.math.sin(lat) * kotlin.math.sin(sunLat) +
                    kotlin.math.cos(lat) * kotlin.math.cos(sunLat) *
                    kotlin.math.cos(lon - sunLon)

                val daylight = ((cosZenith + 0.08) / 0.16).coerceIn(0.0, 1.0)
                val sunShade = 0.24 + 0.76 * daylight
                k *= sunShade
            }

            val rr = (android.graphics.Color.red(color) * k).toInt().coerceIn(0, 255)
            val gg = (android.graphics.Color.green(color) * k).toInt().coerceIn(0, 255)
            val bb = (android.graphics.Color.blue(color) * k).toInt().coerceIn(0, 255)
            out.setPixel(px, py, android.graphics.Color.rgb(rr, gg, bb))
        }
    }
    return out
}

@Composable private fun ObserverBlock(
    lat:String,onLat:(String)->Unit,lon:String,onLon:(String)->Unit,alt:String,onAlt:(String)->Unit,
    qth:String,onQth:(String)->Unit,onApplyQth:()->Unit,onFromCoordinates:()->Unit,
    freq:String,onFreq:(String)->Unit, live:LivePosition?, rec:TleRecord, onLocate:()->Unit
) {
    val observerFocusManager = LocalFocusManager.current
    CardBox("НАБЛЮДАТЕЛЬ И РАДИО") {
        Button(onClick = { observerFocusManager.clearFocus(force = true); onLocate() }, modifier = Modifier.fillMaxWidth()) {
            ControlButtonText("USE MY LOCATION / LOCATOR", fontSize = 11.sp)
        }
        Spacer(Modifier.height(6.dp))
        SmallField("QTH Locator", qth, {
            onQth(it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(8))
        }, Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { observerFocusManager.clearFocus(force = true); onApplyQth() }, modifier = Modifier.weight(1f)) { ControlButtonText("APPLY QTH", fontSize = 11.sp) }
            OutlinedButton(onClick = { observerFocusManager.clearFocus(force = true); onFromCoordinates() }, modifier = Modifier.weight(1f)) { ControlButtonText("LAT/LON → QTH", fontSize = 10.sp) }
        }
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallField("Lat °", lat, onLat, Modifier.weight(1f)); SmallField("Lon °", lon, onLon, Modifier.weight(1f)); SmallField("Alt m", alt, onAlt, Modifier.weight(1f))
        }
        SmallField("Radio MHz", freq, onFreq, Modifier.fillMaxWidth())
    }
}

@Composable private fun LiveBlock(p: LivePosition, freqMHz: String) {
    val df = Sgp4Engine.dopplerHz(p.rangeRateKmS, (freqMHz.toDoubleOrNull() ?: 0.0) * 1e6)
    CardBox("ТЕКУЩЕЕ ПОЛОЖЕНИЕ — SGP4/SDP4") {
        Param("Подспутниковая точка", "${"%.3f".format(p.latitudeDeg)}°, ${"%.3f".format(p.longitudeDeg)}°", "Широта/долгота точки на Земле под спутником")
        Param("Высота", "${"%.1f".format(p.altitudeKm)} km", "SGP4 высота в текущий момент")
        Param("Радиус радиовидимости", "${"%.0f".format(Sgp4Engine.horizonSurfaceRadiusKm(p.altitudeKm))} km", "По поверхности Земли до геометрического горизонта, без учёта рефракции")
        Param("Азимут", "${"%.1f".format(p.azimuthDeg)}°", "Направление от наблюдателя")
        Param("Угол места", "${"%.1f".format(p.elevationDeg)}°", if (p.elevationDeg > 0) "Спутник над горизонтом" else "Спутник ниже горизонта")
        Param("Дальность", "${"%.1f".format(p.rangeKm)} km", "Наклонная дальность до наблюдателя")
        Param("Range rate", "${"%.4f".format(p.rangeRateKmS)} km/s", "Отрицательная — приближается, положительная — удаляется")
        Param("Доплер", "${if(df>=0) "+" else ""}${"%.0f".format(df)} Hz", "Для введённой радиочастоты")
    }
}


private fun maidenheadToLatLon(locatorRaw: String): Pair<Double, Double>? {
    val loc = locatorRaw.trim().uppercase()
    if (loc.length != 4 && loc.length != 6 && loc.length != 8) return null
    val a = loc.toCharArray()
    if (a[0] !in 'A'..'R' || a[1] !in 'A'..'R' || !a[2].isDigit() || !a[3].isDigit()) return null
    var lon = (a[0] - 'A') * 20.0 - 180.0
    var lat = (a[1] - 'A') * 10.0 - 90.0
    lon += (a[2] - '0') * 2.0
    lat += (a[3] - '0') * 1.0
    var lonSize = 2.0
    var latSize = 1.0
    if (loc.length >= 6) {
        if (a[4] !in 'A'..'X' || a[5] !in 'A'..'X') return null
        lonSize /= 24.0; latSize /= 24.0
        lon += (a[4] - 'A') * lonSize
        lat += (a[5] - 'A') * latSize
    }
    if (loc.length >= 8) {
        if (!a[6].isDigit() || !a[7].isDigit()) return null
        lonSize /= 10.0; latSize /= 10.0
        lon += (a[6] - '0') * lonSize
        lat += (a[7] - '0') * latSize
    }
    return (lat + latSize / 2.0) to (lon + lonSize / 2.0)
}

private fun latLonToMaidenhead(latRaw: Double, lonRaw: Double, precision: Int = 6): String {
    val p = when { precision >= 8 -> 8; precision >= 6 -> 6; else -> 4 }
    var lat = latRaw.coerceIn(-90.0, 89.999999999) + 90.0
    var lon = lonRaw.coerceIn(-180.0, 179.999999999) + 180.0
    val fLon = kotlin.math.floor(lon / 20.0).toInt().coerceIn(0,17)
    val fLat = kotlin.math.floor(lat / 10.0).toInt().coerceIn(0,17)
    lon -= fLon * 20.0; lat -= fLat * 10.0
    val sLon = kotlin.math.floor(lon / 2.0).toInt().coerceIn(0,9)
    val sLat = kotlin.math.floor(lat).toInt().coerceIn(0,9)
    val out = StringBuilder().append(('A'.code + fLon).toChar()).append(('A'.code + fLat).toChar()).append(sLon).append(sLat)
    if (p >= 6) {
        lon -= sLon * 2.0; lat -= sLat
        val ssLon = kotlin.math.floor(lon / (2.0 / 24.0)).toInt().coerceIn(0,23)
        val ssLat = kotlin.math.floor(lat / (1.0 / 24.0)).toInt().coerceIn(0,23)
        out.append(('A'.code + ssLon).toChar()).append(('A'.code + ssLat).toChar())
        if (p >= 8) {
            lon -= ssLon * (2.0 / 24.0); lat -= ssLat * (1.0 / 24.0)
            val eLon = kotlin.math.floor(lon / (2.0 / 24.0 / 10.0)).toInt().coerceIn(0,9)
            val eLat = kotlin.math.floor(lat / (1.0 / 24.0 / 10.0)).toInt().coerceIn(0,9)
            out.append(eLon).append(eLat)
        }
    }
    return out.toString()
}

@Composable private fun GroundTrackCanvas(
    points: List<GroundPoint>,
    live: LivePosition?,
    observerLat: Double?,
    observerLon: Double?,
    mapTexture: Bitmap?,
    activeNorad: Int,
    mapSatelliteOrbits: List<MapSatelliteOrbit>
) {
    CardBox("КАРТА ЗЕМЛИ • GROUND TRACK • ЗОНА РАДИОВИДИМОСТИ") {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF071522))
        ) {
            val texture = mapTexture
                ?: BitmapFactory.decodeResource(LocalContext.current.resources, R.drawable.world_map)
            Image(
                bitmap = texture.asImageBitmap(),
                contentDescription = "World map",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                alpha = 0.96f
            )
            Canvas(Modifier.fillMaxSize()) {
                fun normalizeLon(lonRaw: Double): Double {
                    var lon = lonRaw
                    while (lon > 180.0) lon -= 360.0
                    while (lon < -180.0) lon += 360.0
                    return lon
                }

                fun map(gp: GroundPoint): Offset {
                    val lon = normalizeLon(gp.lonDeg)
                    val lat = gp.latDeg.coerceIn(-90.0, 90.0)
                    val x = ((lon + 180.0) / 360.0 * size.width).toFloat()
                    val y = ((90.0 - lat) / 180.0 * size.height).toFloat()
                    return Offset(
                        x.coerceIn(0f, size.width),
                        y.coerceIn(0f, size.height)
                    )
                }

                // Draw a segment using geographic longitude, not screen X.
                // This prevents the near-vertical artifacts that appeared at ±180°.
                fun drawGeoSegment(a: GroundPoint, b: GroundPoint, color: Color, strokeWidth: Float) {
                    val lon1 = normalizeLon(a.lonDeg)
                    val lon2 = normalizeLon(b.lonDeg)
                    val lat1 = a.latDeg.coerceIn(-90.0, 90.0)
                    val lat2 = b.latDeg.coerceIn(-90.0, 90.0)

                    var deltaLon = lon2 - lon1
                    if (kotlin.math.abs(deltaLon) <= 180.0) {
                        drawLine(color, map(a), map(b), strokeWidth)
                        return
                    }

                    // Unwrap the second longitude along the shortest geographic path.
                    val lon2Unwrapped = if (deltaLon > 180.0) lon2 - 360.0 else lon2 + 360.0
                    deltaLon = lon2Unwrapped - lon1
                    if (kotlin.math.abs(deltaLon) < 1e-9) return

                    val crossingLon = if (lon2Unwrapped > 180.0) 180.0 else -180.0
                    val t = ((crossingLon - lon1) / deltaLon).coerceIn(0.0, 1.0)
                    val crossingLat = lat1 + (lat2 - lat1) * t

                    val firstEdge = GroundPoint(crossingLat, crossingLon)
                    val oppositeLon = if (crossingLon > 0.0) -180.0 else 180.0
                    val secondEdge = GroundPoint(crossingLat, oppositeLon)

                    drawLine(color, map(a), map(firstEdge), strokeWidth)
                    drawLine(color, map(secondEdge), map(b), strokeWidth)
                }

                // One orbital period centered around the current time.
                var prevGp: GroundPoint? = null
                points.forEach { gp ->
                    prevGp?.let { drawGeoSegment(it, gp, Accent, 2.2f) }
                    prevGp = gp
                }

                // Additional currently selected satellites.
                // Each entry contains one current orbital period centered on now.
                mapSatelliteOrbits
                    .filter { it.rec.norad != activeNorad && it.track.size > 1 }
                    .forEachIndexed { index, orbit ->
                        val color = secondaryOrbitColor(index).copy(alpha = 0.86f)
                        var previous: GroundPoint? = null
                        orbit.track.forEach { gp ->
                            previous?.let { drawGeoSegment(it, gp, color, 1.8f) }
                            previous = gp
                        }

                        orbit.live?.let { sat ->
                            val footprint = Sgp4Engine.visibilityFootprint(
                                sat.latitudeDeg,
                                sat.longitudeDeg,
                                sat.altitudeKm
                            )
                            var fpPrev: GroundPoint? = null
                            footprint.forEach { gp ->
                                fpPrev?.let {
                                    drawGeoSegment(
                                        it,
                                        gp,
                                        secondaryOrbitColor(index).copy(alpha = 0.78f),
                                        1.7f
                                    )
                                }
                                fpPrev = gp
                            }

                            val p = map(GroundPoint(sat.latitudeDeg, sat.longitudeDeg))
                            drawCircle(secondaryOrbitColor(index), 5.5f, p)
                            drawCircle(Color.White.copy(alpha = 0.8f), 8f, p, style = Stroke(1.2f))
                        }
                    }

                live?.let { sat ->
                    // Geometric radio-horizon footprint for the current SGP4 altitude.
                    val footprint = Sgp4Engine.visibilityFootprint(
                        sat.latitudeDeg,
                        sat.longitudeDeg,
                        sat.altitudeKm
                    )
                    var fpPrevGp: GroundPoint? = null
                    footprint.forEach { gp ->
                        fpPrevGp?.let { drawGeoSegment(it, gp, Color(0xFFFFD166), 2.4f) }
                        fpPrevGp = gp
                    }

                    val satPos = map(GroundPoint(sat.latitudeDeg, sat.longitudeDeg))
                    drawCircle(Color(0xFFFF5252), 9f, satPos)
                    drawCircle(Color.White, 12f, satPos, style = Stroke(2f))

                    if (observerLat != null && observerLon != null) {
                        val obs = map(GroundPoint(observerLat, observerLon))
                        val visible = Sgp4Engine.observerInsideFootprint(
                            sat.latitudeDeg, sat.longitudeDeg, sat.altitudeKm, observerLat, observerLon
                        )
                        val c = if (visible) Good else Color(0xFFFF8A80)
                        drawCircle(c, 7f, obs)
                        drawLine(c, Offset(obs.x - 10f, obs.y), Offset(obs.x + 10f, obs.y), 2f)
                        drawLine(c, Offset(obs.x, obs.y - 10f), Offset(obs.x, obs.y + 10f), 2f)
                    }
                }
            }
        }

        live?.let { sat ->
            val obsVisible = if (observerLat != null && observerLon != null) {
                Sgp4Engine.observerInsideFootprint(sat.latitudeDeg, sat.longitudeDeg, sat.altitudeKm, observerLat, observerLon)
            } else null
            if (obsVisible != null) {
                Text(
                    if (obsVisible) "Станция в зоне радиовидимости" else "Станция вне зоны радиовидимости",
                    fontSize = 11.sp, color = if (obsVisible) Good else Color(0xFFFF8A80), fontWeight = FontWeight.Bold
                )
            }
        }
        Text(
            if (mapSatelliteOrbits.size > 1) {
                "CURRENT ORBITS: ${mapSatelliteOrbits.size} • орбиты и круги радиовидимости выбранных спутников"
            } else {
                "Голубой — ground track • жёлтый — радиовидимость • красный — спутник"
            },
            fontSize = 10.sp,
            color = Color.LightGray
        )
    }
}

@Composable private fun TleFields(r: TleRecord) {
    CardBox("ЧТО ЗАПИСАНО В TLE") {
        Param("NORAD", r.norad.toString(), "Каталожный номер объекта")
        Param("International designator", r.intlDesignator, "Год запуска, номер запуска и объект")
        Param("Epoch", "${r.epochInstant.atZone(ZoneId.of("UTC")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS 'UTC'"))}", "Момент, к которому относятся элементы")
        Param("Inclination i", "${r.inclinationDeg}°", "Наклон плоскости орбиты")
        Param("RAAN Ω", "${r.raanDeg}°", "Положение восходящего узла относительно точки весеннего равноденствия")
        Param("Eccentricity e", r.eccentricity.toString(), "0 — окружность; чем больше, тем более вытянут эллипс")
        Param("Argument of perigee ω", "${r.argPerigeeDeg}°", "Где перигей расположен внутри плоскости орбиты")
        Param("Mean anomaly M", "${r.meanAnomalyDeg}°", "Фазовое положение спутника на epoch")
        Param("Mean motion n", "${r.meanMotionRevDay} rev/day", "Среднее число оборотов за сутки")
        Param("n dot", r.meanMotionDot.toString(), "Первая производная mean motion / 2 в TLE")
        Param("n double-dot", r.meanMotionDdot.toString(), "Вторая производная mean motion / 6 в TLE")
        Param("B*", r.bstar.toString(), "Параметр сопротивления/баллистический drag-параметр SGP4")
        Param("Element set", r.elementSet.toString(), "Номер набора элементов")
        Param("Revolution number", r.revolutionNumber.toString(), "Номер витка на epoch")
    }
}

@Composable private fun RawTle(r:TleRecord) {
    CardBox("ИСХОДНЫЙ TLE") {
        Text(r.name, color=Good, fontWeight=FontWeight.Bold)
        Text(r.line1, fontSize=10.sp, color=Color.LightGray)
        Text(r.line2, fontSize=10.sp, color=Color.LightGray)
    }
}

@Composable private fun CardBox(title:String, modifier:Modifier = Modifier, content:@Composable ColumnScope.()->Unit) {
    Column(modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF24415D), RoundedCornerShape(12.dp)).padding(10.dp)) {
        if (title.isNotBlank()) {
            Text(title, fontWeight=FontWeight.Bold, color=Accent, fontSize=13.sp)
            Spacer(Modifier.height(6.dp))
        }
        content()
    }
}

@Composable private fun Param(name:String,value:String,help:String) {
    Column(Modifier.fillMaxWidth().padding(vertical=3.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text(name, fontSize=12.sp, color=Color.LightGray, modifier=Modifier.weight(0.46f))
            Text(value, fontSize=12.sp, fontWeight=FontWeight.SemiBold, color=Color.White, modifier=Modifier.weight(0.54f))
        }
    }
}

@Composable private fun SmallField(label:String,value:String,on:(String)->Unit,modifier:Modifier) {
    val focusManager = LocalFocusManager.current
    OutlinedTextField(
        value = value,
        onValueChange = on,
        label = { Text(label, fontSize = 10.sp) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(force = true) }),
        modifier = modifier
    )
}

private fun requestBestLocation(context: Context, onSuccess: (Location) -> Unit, onError: (String) -> Unit) {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!fine && !coarse) {
        onError("Locator: нет разрешения на геолокацию")
        return
    }

    val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val providers = buildList {
        if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) add(LocationManager.GPS_PROVIDER)
        if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) add(LocationManager.NETWORK_PROVIDER)
        if (lm.isProviderEnabled(LocationManager.PASSIVE_PROVIDER)) add(LocationManager.PASSIVE_PROVIDER)
    }.distinct()

    if (providers.isEmpty()) {
        onError("Locator: включите Location/GPS в настройках Android")
        return
    }

    try {
        val last = providers.mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 5 * 60 * 1000L) {
            onSuccess(last)
            return
        }

        val provider = providers.first()
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                runCatching { lm.removeUpdates(this) }
                onSuccess(location)
            }
            override fun onProviderDisabled(provider: String) {}
            override fun onProviderEnabled(provider: String) {}
            @Deprecated("Deprecated in Android")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
    } catch (e: SecurityException) {
        onError("Locator: нет доступа к местоположению")
    } catch (e: Exception) {
        onError("Locator: ${e.message ?: "ошибка определения координат"}")
    }
}

private data class TleDownloadResult(val text: String, val sourceLabel: String)

private fun downloadTleLegacy056(): TleDownloadResult {
    val sources = listOf(
        "http://r4uab.ru/satonline.txt" to "R4UAB HTTP / satonline.txt",
        "https://r4uab.ru/satonline.txt" to "R4UAB HTTPS / satonline.txt",
        "https://satgs.ru/satonline.txt" to "SATGS backup / satonline.txt"
    )
    val errors = mutableListOf<String>()
    for ((url, label) in sources) {
        try {
            val text = download(url)
            if (!looksLikeTle(text)) error("ответ не похож на TLE")
            return TleDownloadResult(text, label)
        } catch (e: Exception) {
            errors += "$label: ${e.message ?: e.javaClass.simpleName}"
        }
    }
    error(errors.joinToString(" | "))
}

private data class TleSourceOption(
    val id: String,
    val menuLabel: String,
    val sourceLabel: String,
    val urls: List<String>
)

private val TLE_SOURCE_OPTIONS = listOf(
    TleSourceOption(
        id = "auto",
        menuLabel = "AUTO / как в 0.1.56",
        sourceLabel = "AUTO",
        urls = listOf(
            // Сначала источник, который уже использовался в стабильной 0.1.56.
            "http://r4uab.ru/satonline.txt",
            // Затем наиболее надёжный HTTPS-файл AMSAT.
            "https://www.amsat.org/tle/current/nasabare.txt",
            // Резерв R4UAB по HTTPS.
            "https://r4uab.ru/satonline.txt",
            // CelesTrak Amateur Radio.
            "https://celestrak.org/NORAD/elements/gp.php?GROUP=amateur&FORMAT=TLE",
            // Дополнительный резерв.
            "https://satgs.ru/satonline.txt"
        )
    ),
    TleSourceOption(
        id = "r4uab",
        menuLabel = "R4UAB / satonline.txt",
        sourceLabel = "R4UAB / satonline.txt",
        urls = listOf(
            "http://r4uab.ru/satonline.txt",
            "https://r4uab.ru/satonline.txt"
        )
    ),
    TleSourceOption(
        id = "amsat",
        menuLabel = "AMSAT-NA / nasabare.txt",
        sourceLabel = "AMSAT-NA / nasabare.txt",
        urls = listOf(
            "https://www.amsat.org/tle/current/nasabare.txt",
            "https://www.amsat.org/tle/current/dailytle.txt"
        )
    ),
    TleSourceOption(
        id = "celestrak",
        menuLabel = "CelesTrak / Amateur Radio",
        sourceLabel = "CelesTrak / Amateur Radio",
        urls = listOf(
            "https://celestrak.org/NORAD/elements/gp.php?GROUP=amateur&FORMAT=TLE",
            "https://www.celestrak.org/NORAD/elements/gp.php?GROUP=amateur&FORMAT=TLE"
        )
    ),
    TleSourceOption(
        id = "satgs",
        menuLabel = "SATGS / satonline.txt",
        sourceLabel = "SATGS / satonline.txt",
        urls = listOf("https://satgs.ru/satonline.txt")
    )
)

private fun sourceLabelForUrl(source: TleSourceOption, url: String): String {
    if (source.id != "auto") return source.sourceLabel
    return when {
        "r4uab.ru" in url -> "R4UAB / satonline.txt"
        "amsat.org" in url -> "AMSAT-NA"
        "celestrak.org" in url -> "CelesTrak / Amateur Radio"
        "satgs.ru" in url -> "SATGS / satonline.txt"
        else -> "TLE"
    }
}

private fun downloadTleSource(sourceId: String): TleDownloadResult {
    if (sourceId == "auto") {
        return downloadTleLegacy056()
    }

    val source = TLE_SOURCE_OPTIONS.firstOrNull { it.id == sourceId }
        ?: error("Неизвестный источник TLE: $sourceId")

    val errors = mutableListOf<String>()
    for (url in source.urls) {
        try {
            val text = download(url)
            if (!looksLikeTle(text)) {
                error("получен ответ, но TLE в нём не найден")
            }
            return TleDownloadResult(text, sourceLabelForUrl(source, url))
        } catch (e: Exception) {
            val host = runCatching { URL(url).host }.getOrDefault(url)
            errors += "$host: ${e.message ?: e.javaClass.simpleName}"
        }
    }
    error(errors.joinToString(" | "))
}


private fun runNetworkDiagnostics(): String {
    val lines = mutableListOf<String>()

    val dnsTargets = listOf(
        "r4uab.ru",
        "www.amsat.org",
        "celestrak.org",
        "satgs.ru"
    )

    var anyDnsOk = false
    for (host in dnsTargets) {
        val dns = runCatching {
            val addrs = java.net.InetAddress.getAllByName(host)
            anyDnsOk = anyDnsOk || addrs.isNotEmpty()
            if (addrs.isNotEmpty()) {
                "OK (${addrs.first().hostAddress})"
            } else {
                "FAIL"
            }
        }.getOrElse { e ->
            "FAIL (${e.message ?: e.javaClass.simpleName})"
        }
        lines += "DNS $host: $dns"
    }

    lines.add(0, if (anyDnsOk) "INTERNET/DNS: OK" else "INTERNET/DNS: FAIL")

    val urls = listOf(
        "R4UAB" to "http://r4uab.ru/satonline.txt",
        "AMSAT" to "https://www.amsat.org/tle/current/nasabare.txt",
        "CelesTrak" to "https://celestrak.org/NORAD/elements/gp.php?GROUP=amateur&FORMAT=TLE",
        "SATGS" to "https://satgs.ru/satonline.txt"
    )

    for ((label, url) in urls) {
        val result = runCatching {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Kepler-Orbit-Tutor/0.1.15 (Android; UA1CFM)")
                setRequestProperty("Accept", "text/plain,*/*")
                setRequestProperty("Accept-Encoding", "identity")
                useCaches = false
            }
            try {
                val code = c.responseCode
                if (code !in 200..299) {
                    "HTTP $code"
                } else {
                    val sample = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(4096) }
                    if (looksLikeTle(sample)) "OK" else "HTTP $code, но TLE не найден"
                }
            } finally {
                c.disconnect()
            }
        }.getOrElse { e ->
            "FAIL (${e.message ?: e.javaClass.simpleName})"
        }
        lines += "$label: $result"
    }

    if (!anyDnsOk) {
        lines += ""
        lines += "Причина похожа на DNS/сеть устройства."
    }

    return lines.joinToString("\n")
}

private fun looksLikeTle(text: String): Boolean {
    val lines = text.lineSequence().map { it.trimEnd() }.filter { it.isNotBlank() }.take(80).toList()
    val hasL1 = lines.any { it.startsWith("1 ") && it.length >= 60 }
    val hasL2 = lines.any { it.startsWith("2 ") && it.length >= 60 }
    return hasL1 && hasL2
}

private fun download(url:String):String {
    val c = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15000
        readTimeout = 20000
        requestMethod = "GET"
        instanceFollowRedirects = true
        setRequestProperty("User-Agent", "Kepler-Orbit-Tutor/0.1.15 (Android; UA1CFM)")
        setRequestProperty("Accept", "text/plain,*/*")
        setRequestProperty("Accept-Encoding", "identity")
        useCaches = false
    }
    try {
        if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    } finally { c.disconnect() }
}
